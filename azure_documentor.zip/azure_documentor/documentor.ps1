<#
	Script Name	:	azure_documentor.ps1
	Author		:	Deepak Venugopal
	Synopsis	:	This script is used to create readme files for resources deployed in Azure
	
	This script is part of the PS Automator Reporting & Automation Platform
#>

<# --- Ground rules for the script to function --- #>
#Requires -Version 5.0
$ErrorActionPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

#region Script Declarations	
# The path to the definitions yaml file
[string] $DefinitionsFile = "definitions.yml"

# The name of the Entra Tenant
[string] $TenantName = "akersolutions.onmicrosoft.com"

# The ID of the Entra Tenant
[string] $TenantId = "26b749f6-8c72-44e3-bbde-ae3de07b4206"

[string] $OutputFolder = "C:\Users\HU929503S\aker_iac_project\azure_documentor\dynamic"

# Set this to $true if verbose logging is required on the output window
# Accepted values are $true and $false
[bool] $VerboseLogging = $true

# Set this to $true if a log file is to be created during the execution
# Accepted values are $true and $false
[bool] $GenerateLogFile = $true

# Name of the logfile to be created
# eg: /root/powershell/script.log
[string] $LogLocation = "C:\Users\HU929503S\aker_iac_project\azure_documentor\logs"

#endregion Script Declarations	

#region Script Methods	

function GatherBasicInfo() {
    
    WriteLog -Type 1 -Message "Gathering information on management groups and subscriptions in $TenantName"

    $Global:managementGroups = @()
    $Global:subscriptions = @()

    #$managementGroupCollection = Get-AzManagementGroup

    ##### For specific Management group ########

    
    $mgmt= Read-Host "Enter Management Group:"

    $managementGroupCollection = (Get-AzManagementGroup | Where-Object { $_.Name -eq $mgmt }).Name

    foreach ($mg in $managementGroupCollection) {

        $mg = Get-AzManagementGroup -GroupName $mg
        
        $subscriptionCollection = Get-AzManagementGroupSubscription -GroupName $mg.DisplayName

 #########################################################

   <# foreach ($mg in $managementGroupCollection) {

        $mg = Get-AzManagementGroup -GroupName $mg.Name

        $subscriptionCollection = Get-AzManagementGroupSubscription -GroupId $mg.name
        #>
        $Global:managementGroups += @{
            Name              = $mg.Name
            DisplayName       = $mg.DisplayName
            ParentName        = $mg.ParentName
            ParentDisplayName = $mg.ParentDisplayName
            ParentId          = $mg.ParentId
            Subscriptions     = $subscriptionCollection.DisplayName
        }

        foreach ($sub in $subscriptionCollection) {

            $subscriptionDetails = Get-AzSubscription -SubscriptionName $sub.DisplayName

            $Global:subscriptions += @{
                Name            = $subscriptionDetails.Name
                ID              = $subscriptionDetails.Id
                State           = $subscriptionDetails.State
                ManagementGroup = $mg.Name
            }

        }
    }

    WriteLog -Type 1 -Message "Identified $($Global:managementGroups.Count) management groups in $TenantName"
    WriteLog -Type 1 -Message "Identified $($Global:subscriptions.Count) subscriptions in $TenantName"

}

function GatherManagementGroupInfo() {
    $fileName = "$OutputFolder\$($Definitions.management_group.file_name)"
       
    try {
        if ($Global:managementGroups.Count -gt 0) {

            WriteLog -Type 1 -Message "Generating summary file for management groups"
                    
            GenerateHeader -DefinitionType "management_group" >> $fileName

            "The following management groups have been identified in the tenant **$TenantName**," >> $fileName
            " " >> $fileName
            "| **No.** | **Name** | **Subscriptions** |" >> $fileName
            "| ----| ---- | ------------- |" >> $fileName
            [int]$count = 1;
            
            foreach ($mg in $Global:managementGroups) {
                [string]$subscriptionList = ""
                foreach ($subscription in $mg.subscriptions) {
                    $subscriptionList += "[$subscription](subscriptions/$(FormatName -Name $subscription).md), "
                }

                $subscriptionList = $subscriptionList.TrimEnd(", ")

                "| $count | $($mg.Name) | $subscriptionList |" >> $fileName
                $count ++;
            }
        
            "## Management Group Layout" >> $fileName
            " " >> $fileName
            "`````````mermaid " >> $fileName
            "graph TD;" >> $fileName

            foreach ($mg in $Global:managementGroups) {
                "$($mg.ParentName)[$($mg.ParentDisplayName)] -->$($mg.Name)[$($mg.DisplayName)];" >> $fileName
                "$($mg.Name)[$($mg.DisplayName)] --> $($mg.Name)-subs([$($mg.subscriptions.Count) Subscriptions]);" >> $fileName
            }
            "````````` " >> $fileName
            
            GenerateCreationGuide -DefinitionType "management_group" >> $fileName
            GenerateSupportInfo >> $fileName

        }
    }
    catch {
        WriteLog -Type 3 -Message "Unable to gather information on management groups"
        WriteLog -Type 3 $_
    }
}

function GatherSubscriptionInfo() {

    WriteLog -Type 1 -Message "Generating summary file for subscriptions"
    $fileName = "$OutputFolder\subscriptions.md"

    try {
        
        if ($Global:subscriptions.Count -gt 0) {

            [int]$count = 1;

             $Global:sub= Read-Host "Enter Subscription:"
            
            GenerateHeader -DefinitionType "subscription" >> $fileName

            "The following subscriptions have been identified in the tenant **$TenantName**," >> $fileName
            " " >> $fileName
            "| **No.** | **ID** | **Name** | **Management Group** | **State** |" >> $fileName
            "| ----| -- | ---- | ---------------- | ----- |" >> $fileName
            [int]$count = 1;

            foreach ($subscription in $Global:subscriptions) {
            
           

               # "| $count | [$($subscription.Id)](subscriptions/$(FormatName -Name $subscription.Name).md) | [$($subscription.Name)](subscriptions/$(FormatName -Name $subscription.Name).md) | $($subscription.ManagementGroup) | $($subscription.State)" >> $fileName                
               # $count ++;

                           ############ For specific Subscription ########
            
       
             if ($subscription["Name"] -eq $Global:sub) {
               
               "| $count | [$($subscription.Id)](subscriptions/$(FormatName -Name $subscription.Name).md) | [$($subscription.Name)](subscriptions/$(FormatName -Name $subscription.Name).md) | $($subscription.ManagementGroup) | $($subscription.State)" >> $fileName                
                $count ++;
              }
          ###########################################################  

            }
           
            GenerateCreationGuide -DefinitionType "subscription" >> $fileName
            GenerateSupportInfo >> $fileName
            
            if (-not(Test-Path "$OutputFolder\subscriptions" -PathType Container)) {
                New-Item -path "$OutputFolder\subscriptions" -ItemType Directory | Out-Null
            }

            GetSubscriptionDetails

        }
    }

    catch {
        WriteLog -Type 3 -Message "Unable to gather information on subscriptions"
        WriteLog -Type 3 $_
    }
}

function GetSubscriptionDetails() {
    try {
        
        if ($Global:subscriptions.Count -gt 0) {           

            foreach ($subscription in $Global:subscriptions) {
        
                <#$fileName = "$OutputFolder\subscriptions\$(FormatName -Name $subscription.Name).md"

                WriteLog -Type 1 -Message "Gathering detailed data for the subscription $($subscription.Name)"
                
                Set-AzContext -Subscription $subscription.Id | Out-Null               
                $resourceGroups = Get-AzResourceGroup -ErrorAction SilentlyContinue

                "## Azure Subscription - $($subscription.Name)" > $fileName
                
                "## Basic Information" >> $fileName

                "| **Name** | **Id** | **Management Group** | **State** | **Resource Groups** |" >> $fileName
                "| -- | -- | -- | -- | -- |" >> $fileName
                "| $($subscription.Name)| $($subscription.Id) |$($subscription.ManagementGroup) | $($subscription.State) | $($resourceGroups.Count) |" >> $fileName
                #>
              
              ################## Specific Subscription ###########################

                if ($subscription["Name"] -eq $Global:Sub) {
                   
                $fileName = "$OutputFolder\subscriptions\$(FormatName -Name $subscription.Name).md"

                WriteLog -Type 1 -Message "Gathering detailed data for the subscription $($subscription.Name)"
                
                Set-AzContext -Subscription $subscription.Id | Out-Null               
                $resourceGroups = Get-AzResourceGroup -ErrorAction SilentlyContinue

                "## Azure Subscription - $($subscription.Name)" > $fileName
                
                "## Basic Information" >> $fileName

                "| **Name** | **Id** | **Management Group** | **State** | **Resource Groups** |" >> $fileName
                "| -- | -- | -- | -- | -- |" >> $fileName
                "| $($subscription.Name)| $($subscription.Id) |$($subscription.ManagementGroup) | $($subscription.State) | $($resourceGroups.Count) |" >> $fileName
            

                GenerateResourceGroupInfo  -subscription $subscription
                GenerateVirtualMachineInfo -subscription $subscription
                GenerateVirtualNetworkInfo -subscription $subscription
                GenerateStorageAccountInfo -subscription $subscription
                GenerateSqlServerInfo      -subscription $subscription
                GenerateAppServiceInfo     -subscription $subscription
                GenerateKeyVaultInfo       -subscription $subscription
                GenerateLoadBalancerInfo   -subscription $subscription
                GenerateAppGatewayInfo     -subscription $subscription
                GenerateRecoveryVaultInfo  -subscription $subscription



                            
                
                GenerateSupportInfo >> $fileName
       }
         ####################################################################################
            }

        }
    }

    catch {
        WriteLog -Type 3 -Message "Unable to gather information on subscriptions"
        WriteLog -Type 3 $_
    }

}

function GenerateResourceGroupInfo() {
    Param ( [object]$subscription )

    # ensure both output folders exist ------------------------------------------------
    foreach ($dir in @("$OutputFolder\resourcegroups", "$OutputFolder\subscriptions")) {
        if (-not (Test-Path $dir -PathType Container)) {
            New-Item -Path $dir -ItemType Directory | Out-Null
        }
    }

    try {
        WriteLog -Type 1 -Message "Gathering information on resource groups in the subscription $($subscription.Name)"
        $resourceGroups = Get-AzResourceGroup -ErrorAction SilentlyContinue
    
        if ($resourceGroups.Count -gt 0) {

            [string] $fileName = "$OutputFolder\subscriptions\$(FormatName -Name $subscription.Name).md"

            "## Resource Groups" >> $fileName
            "The following resource groups have been identified in the subscription **$($subscription.Name)**," >> $fileName
            " " >> $fileName
            "| **Name** | **Location** | **Details** |" >> $fileName
            "| -- | -- | -- |" >> $fileName
    
            foreach ($rg in $resourceGroups) {
                "| $($rg.ResourceGroupName) | $($rg.Location) | [View](../resourcegroups/$(FormatName -Name $subscription.Name)_$(FormatName -Name $rg.ResourceGroupName).md) |" >> $fileName
            
                $rgFileName = "$OutputFolder\resourcegroups\$(FormatName -Name $subscription.Name)_$(FormatName -Name $rg.ResourceGroupName).md"

                "## Resource Group  - $($rg.ResourceGroupName)" > $rgFileName
                ""                      >> $rgFileName
                "---"                   >> $rgFileName
                            
                # ── Resources & overview data -------------------------------------------------
                $resources = Get-AzResource -ResourceGroupName $rg.ResourceGroupName -ErrorAction SilentlyContinue
                if (-not $resources) { $resources = @() }
                $resourcesByType = $resources | Group-Object -Property ResourceType
                $overviewData = @()

                foreach ($group in $resourcesByType) {
                    $regions = ($group.Group | Select-Object -ExpandProperty Location | Sort-Object -Unique) -join ", "
                    $deploys = Get-AzResourceGroupDeployment -ResourceGroupName $rg.ResourceGroupName -ErrorAction SilentlyContinue
                    if ($deploys) {
                        $last = $deploys | Sort-Object Timestamp -Descending | Select-Object -First 1
                        $ldate = $last.Timestamp.ToString("yyyy-MM-dd")
                    }
                    else { $ldate = '-' }

                    $overviewData += [pscustomobject]@{
                        ResourceType  = $group.Name
                        ResourceCount = $group.Count
                        Regions       = $regions
                        LastDeploy    = $ldate
                    }
                }

                # ── Creation date RG
                $creationDate = (Search-AzGraph -Query "
                    resourcecontainers
                    | where type == 'microsoft.resources/resourcegroups'
                    | where name == '$($rg.ResourceGroupName)'
                                    " -First 1 -ErrorAction SilentlyContinue).createdTime

                if (-not $creationDate) { $creationDate = '-' } else {
                    $creationDate = ([datetime]$creationDate).ToString('yyyy-MM-dd')
                }

                " "  >> $rgFileName                  # ← blank line
                # ── Basic Information --------------------------------------------------------
                "### Basic Information" >> $rgFileName
                ""                      >> $rgFileName
                "---"                   >> $rgFileName
                "| **Subscription Name** | **Resource Group Name** | **Location** | " >> $rgFileName
                "| ----------------------| ------------------------| -------------| " >> $rgFileName
                "| $($subscription.name) | $($rg.ResourceGroupName) | $($rg.Location) | " >> $rgFileName 
                
                
                " "  >> $rgFileName                  # ← blank line


                # ── Tags ---------------------------------------------------------------------
                " " >> $rgFileName
                "### Tags" >> $rgFileName
                ""                      >> $rgFileName
                "---"                   >> $rgFileName
                "| Tag key | Tag value |" >> $rgFileName
                "|---------|-----------|" >> $rgFileName

                if ($rg.Tags) {
                    foreach ($tag in $rg.Tags.GetEnumerator()) {
                        "| $($tag.Key) | $($tag.Value) |" >> $rgFileName
                    }
                }
                else {
                    "| - | No tags available |" >> $rgFileName
                }

                " "  >> $rgFileName                  # ← blank line
                # ── resource Group - Resource details--------------------------------------------------------
                " " >> $rgFileName
                "### Resources Details" >> $rgFileName
                ""                      >> $rgFileName
                "---"                   >> $rgFileName
                "The following is a breakdown of resource types within this resource group:" >> $rgFileName
                " " >> $rgFileName
                "| **Resource Type** | **Resource Count** | **Regions** | **Deploy Date** |" >> $rgFileName
                "|-------------------|--------------------|-------------|-----------------|" >> $rgFileName

                foreach ($item in $overviewData) {
                    "| $($item.ResourceType) | $($item.ResourceCount) | $($item.Regions) | $($item.LastDeploy) |" >> $rgFileName
                }

                " "  >> $rgFileName                  # ← blank line
                # ── Locks Applied ------------------------------------------------------------
                " " >> $rgFileName
                "### Locks Applied" >> $rgFileName
                ""                      >> $rgFileName
                "---"                   >> $rgFileName
                $locks = Get-AzResourceLock -ResourceGroupName $rg.ResourceGroupName -ErrorAction SilentlyContinue

                if ($locks) {
                    # works for 1 or many
                    "| Lock name | Lock type | Notes |" >> $rgFileName
                    "|-----------|-----------|-------|" >> $rgFileName

                    foreach ($lock in @($locks)) {

                        $level = if ($lock.Level  ) { $lock.Level }
                        elseif ($lock.Properties -and $lock.Properties.Level ) { $lock.Properties.Level }
                        else { '-' }

                        $notes = if ($lock.Notes  ) { $lock.Notes }
                        elseif ($lock.Properties -and $lock.Properties.Notes) { $lock.Properties.Notes }
                        else { '-' }

                        "| $($lock.Name) | $level | $notes |" >> $rgFileName
                    }
                }
                else {
                    "| No locks applied | |" >> $rgFileName
                }

                " "  >> $rgFileName                  # ← blank line
                # Role Assignments ---------------------------------------------------------------

                " " >> $rgFileName

                "### Role Assignments" >> $rgFileName
                ""                      >> $rgFileName
                "---"                   >> $rgFileName
                # Get role assignments scoped to this resource group
                $roleAssignments = Get-AzRoleAssignment -ResourceGroupName $rg.ResourceGroupName -ErrorAction SilentlyContinue

                if ($roleAssignments -and $roleAssignments.Count -gt 0) {
                    "| **Principal Name** | **Role** | **Principal Type** | **Scope** |" >> $rgFileName
                    "|--------------------|----------|--------------------|-----------|" >> $rgFileName

                    foreach ($ra in $roleAssignments) {
                        # Resolve principal display name if possible
                        $principalName = $ra.DisplayName
                        if (-not $principalName) {
                            $principalName = $ra.SignInName
                        }
                        if (-not $principalName) {
                            $principalName = $ra.ObjectId
                        }

                        "| $principalName | $($ra.RoleDefinitionName) | $($ra.PrincipalType) | $($ra.Scope) |" >> $rgFileName
                    }
                }
                else {
                    "| No role assignments found on this resource group | | | |" >> $rgFileName
                }

                " "  >> $rgFileName                  # ← blank line  

            }
        }  
    }
    catch {
        WriteLog -Type 3 -Message "There was a problem in gathering information on resource groups in the subscription $($subscription.Name)"
        WriteLog -Type 3 $_
    }
}

function GenerateVirtualMachineInfo() {
    Param ( [object]$subscription )

    # Ensure output folders
    foreach ($d in @("$OutputFolder\subscriptions", "$OutputFolder\virtualmachines")) {
        if (-not (Test-Path $d -PathType Container)) {
            New-Item -Path $d -ItemType Directory | Out-Null
        }
    }

    try {
        WriteLog -Type 1 -Message "Gathering information on virtual machines in the subscription $($subscription.Name)"
        $virtualMachines = Get-AzVM -ErrorAction SilentlyContinue

        $fileName = "$OutputFolder\subscriptions\$(FormatName -Name $subscription.Name).md"

        if ($virtualMachines.Count -gt 0) {
            "## Virtual Machines"                                                          >> $fileName
            "The following virtual machines have been identified in the subscription **$($subscription.Name)**:" >> $fileName
            ' '                                                                            >> $fileName
            "| **Name** | **Resource Group** | **Location** | **SKU** | **OS Type** | **Details** |" >> $fileName
            "|----------|--------------------|--------------|---------|-------------|-------------|" >> $fileName


            foreach ($vm in $virtualMachines) {

                [string] $vmFileName = "$OutputFolder\virtualmachines\$(FormatName -Name $vm.Name).md"

                "| $($vm.Name) | $($vm.ResourceGroupName) | $($vm.Location) | $($vm.HardwareProfile.VmSize) | $($vm.StorageProfile.OsDisk.OsType) | [View](../virtualmachines/$(FormatName -Name $vm.Name).md) |" >> $fileName




                "### Virtual Machine Info $($vm.Name)"  >  $vmFileName
                '---'                                     >> $vmFileName
                ' '                                       >> $vmFileName


                # ── Basic Information ────────────────────────────────────────────
                "### Basic Information"                   >> $vmFileName
                '---'                                     >> $vmFileName
                ' '                                       >> $vmFileName
                "| **Name** | **Resource Group** | **Location** | **Size** | **OS Type** |" >> $vmFileName
                "|----------|-------------------|--------------|----------|-------------|"   >> $vmFileName
                "| $($vm.Name) | $($vm.ResourceGroupName) | $($vm.Location) | $($vm.HardwareProfile.VmSize) | $($vm.StorageProfile.OsDisk.OsType) |" >> $vmFileName
                ' '                                       >> $vmFileName


                # ── Disks ────────────────────────────────────────────────────────
                "### Disks"                               >> $vmFileName
                '---'                                     >> $vmFileName
                ' '                                       >> $vmFileName
                "| **Disk Name** | **Type** | **Size (GB)** |" >> $vmFileName
                "|--------------|----------|---------------|"     >> $vmFileName

                $osDiskObj = Get-AzDisk -ResourceGroupName $vm.ResourceGroupName -DiskName $vm.StorageProfile.OsDisk.Name -ErrorAction SilentlyContinue
                $osSize = if ($osDiskObj) { $osDiskObj.DiskSizeGB } else { 'N/A' }
                "| $($vm.StorageProfile.OsDisk.Name) | OS | $osSize |" >> $vmFileName

                foreach ($d in $vm.StorageProfile.DataDisks) {
                    $dataDiskObj = Get-AzDisk -ResourceGroupName $vm.ResourceGroupName -DiskName $d.Name -ErrorAction SilentlyContinue
                    $dataSize = if ($dataDiskObj) { $dataDiskObj.DiskSizeGB } else { 'N/A' }
                    "| $($d.Name) | Data | $dataSize |" >> $vmFileName
                }
                ' '                                       >> $vmFileName


                # ── Network Interfaces ──────────────────────────────────────────
                "### Network Interfaces"                  >> $vmFileName
                '---'                                     >> $vmFileName
                ' '                                       >> $vmFileName
                "| **NIC** | **Private IPs** |"           >> $vmFileName
                "|---------|-----------------|"           >> $vmFileName

                foreach ($id in $vm.NetworkProfile.NetworkInterfaces.Id) {
                    $nicName = ($id -split '/')[8]
                    $nic = Get-AzNetworkInterface -Name $nicName -ResourceGroupName $vm.ResourceGroupName -ErrorAction SilentlyContinue
                    if ($nic) {
                        $ips = $nic.IpConfigurations | Select-Object -ExpandProperty PrivateIpAddress -Unique
                        "| $($nic.Name) | $($ips -join ', ') |" >> $vmFileName
                    }
                }
                ' '                                       >> $vmFileName


                # ── Power State ─────────────────────────────────────────────────
                $pstate = (Get-AzVM -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName -Status).Statuses |
                Where-Object Code -like 'PowerState/*' |
                Select-Object -ExpandProperty DisplayStatus
                if (-not $pstate) { $pstate = 'Unknown' }

                "### Power State"                         >> $vmFileName
                '---'                                     >> $vmFileName
                ' '                                       >> $vmFileName
                "**$pstate**"                             >> $vmFileName
                ' '                                       >> $vmFileName


                # ── Tags ────────────────────────────────────────────────────────
                "### Tags"                                >> $vmFileName
                '---'                                     >> $vmFileName
                ' '                                       >> $vmFileName
                "| Tag | Value |"                         >> $vmFileName
                "|-----|-------|"                         >> $vmFileName
                if ($vm.Tags) {
                    foreach ($tag in $vm.Tags.GetEnumerator()) {
                        "| $($tag.Key) | $($tag.Value) |" >> $vmFileName
                    }
                }
                else {
                    "| - | - |"                           >> $vmFileName
                }
                ' '                                       >> $vmFileName

                $vmAdvisorRecs = Get-AzAdvisorRecommendation -ResourceId $vm.Id -ErrorAction SilentlyContinue

                # ── Advisor Score Summary (always shown) ─────────────────────────────────────
                $totalCount = $vmAdvisorRecs.Count
                $highCount = ($vmAdvisorRecs | Where-Object { $_.Impact -eq 'High' }).Count
                $mediumCount = ($vmAdvisorRecs | Where-Object { $_.Impact -eq 'Medium' }).Count
                $lowCount = ($vmAdvisorRecs | Where-Object { $_.Impact -eq 'Low' }).Count

                "### Advisor Summary"               >> $vmFileName
                '---'                                     >> $vmFileName
                ""                                        >> $vmFileName
                "| Metric               | Value |"        >> $vmFileName
                "|----------------------|-------|"         >> $vmFileName
                "| Total Recommendations| $totalCount |"   >> $vmFileName
                "| High Impact          | $highCount |"    >> $vmFileName
                "| Medium Impact        | $mediumCount |"  >> $vmFileName
                "| Low Impact           | $lowCount |"     >> $vmFileName
                ""                                        >> $vmFileName

                # ── Advisor Recommendations (details) ────────────────────────────────────────
                "### Advisor Recommendations"             >> $vmFileName
                '---'                                     >> $vmFileName
                ""                                        >> $vmFileName

                if ($vmAdvisorRecs -and $vmAdvisorRecs.Count -gt 0) {
                    "| **Category** | **Impact** | **Recommendation** |" >> $vmFileName
                    "|--------------|-----------|--------------------|"  >> $vmFileName

                    foreach ($rec in $vmAdvisorRecs) {
                        # Helper to get nested property safely
                        function Get-NestedValue([object]$o, [string]$p) {
                            if ($o -and ($o.PSObject.Properties.Match($p)).Count) { return $o.$p }
                            return $null
                        }

                        $recommendation = @(
                            Get-NestedValue $rec.ShortDescription 'Recommendation'
                            Get-NestedValue $rec.ShortDescription 'Solution'
                            Get-NestedValue $rec.ShortDescription 'Text'
                            Get-NestedValue $rec.ShortDescription 'Problem'
                            Get-NestedValue $rec 'Description'
                            Get-NestedValue $rec 'Message'
                            Get-NestedValue $rec 'RecommendedAction'
                            Get-NestedValue $rec.ExtendedProperties 'recommendationTypeDisplayName'
                            Get-NestedValue $rec.ExtendedProperties 'recommendationText'
                            Get-NestedValue $rec.ExtendedProperties 'solution'
                            Get-NestedValue $rec.ExtendedProperties 'description'
                        ) | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1

                        if (-not $recommendation) { $recommendation = '—' }
                        $recommendation = $recommendation -replace '\|', '\|'

                        $category = $rec.Category -replace '\|', '\|'
                        $impact = $rec.Impact -replace '\|', '\|'

                        "| $category | $impact | $recommendation |" >> $vmFileName
                    }
                }
                else {
                    "No Advisor recommendations (Operational Excellence, Reliability, or Security) for this VM." >> $vmFileName
                }

            } 
        }
    }
    catch {
        WriteLog -Type 3 -Message "There was a problem in gathering information on virtual machines in the subscription $($subscription.Name)"
        WriteLog -Type 3 $_
    }
}

function GetFreeCidrs { 
    param(
        [string]$vnetCidr,
        [string[]]$subnetCidrs
    )

    function IPToUInt32 {
        param([string]$ip)
        $bytes = [System.Net.IPAddress]::Parse($ip).GetAddressBytes()
        [Array]::Reverse($bytes)
        return [BitConverter]::ToUInt32($bytes, 0)
    }

    function UInt32ToIP {
        param([uint32]$int)
        $bytes = [BitConverter]::GetBytes($int)
        [Array]::Reverse($bytes)
        return [System.Net.IPAddress]::new($bytes).ToString()
    }

    function Get-CidrsFromRange {
        param(
            [string]$startIP,
            [string]$endIP
        )

        $start = IPToUInt32 $startIP
        $end = IPToUInt32 $endIP
        $cidrs = @()

        while ($start -le $end) {
            $maxSize = 32
            while ($maxSize -gt 0) {
                $blockSize = [math]::Pow(2, 32 - $maxSize)
                # Check alignment of start to block size
                if (($start % $blockSize) -ne 0) { break }
                # Check if block fits in range
                if (($start + $blockSize - 1) -gt $end) { break }
                $maxSize--
            }
            $maxSize++

            $ipString = UInt32ToIP ([uint32]$start)
            $cidrs += "$ipString/$maxSize"
            $start += [math]::Pow(2, 32 - $maxSize)
        }

        return $cidrs
    }

    $vnetNetwork, $vnetPrefixLength = $vnetCidr.Split('/')
    $vnetNetworkInt = IPToUInt32 $vnetNetwork
    $vnetPrefixLength = [int]$vnetPrefixLength
    $mask = ([uint32]([math]::Pow(2, 32) - 1) - ([math]::Pow(2, 32 - $vnetPrefixLength) - 1))

    $vnetStart = $vnetNetworkInt -band $mask
    $vnetEnd = $vnetStart + [math]::Pow(2, 32 - $vnetPrefixLength) - 1

    $usedRanges = @()
    foreach ($subnet in $subnetCidrs) {
        $subNetAddr, $subPrefix = $subnet.Split('/')
        $subNetInt = IPToUInt32 $subNetAddr
        $subPrefix = [int]$subPrefix
        $subMask = ([uint32]([math]::Pow(2, 32) - 1) - ([math]::Pow(2, 32 - $subPrefix) - 1))
        $subStart = $subNetInt -band $subMask
        $subEnd = $subStart + [math]::Pow(2, 32 - $subPrefix) - 1
        $usedRanges += [PSCustomObject]@{ Start = $subStart; End = $subEnd }
    }

    $usedRanges = $usedRanges | Sort-Object Start
    $freeRanges = @()
    $currentStart = $vnetStart

    foreach ($range in $usedRanges) {
        if ($currentStart -lt $range.Start) {
            $freeRanges += [PSCustomObject]@{ Start = $currentStart; End = $range.Start - 1 }
        }
        $currentStart = [math]::Max($currentStart, $range.End + 1)
    }

    if ($currentStart -le $vnetEnd) {
        $freeRanges += [PSCustomObject]@{ Start = $currentStart; End = $vnetEnd }
    }

    $freeCIDRs = foreach ($free in $freeRanges) {
        $startIP = UInt32ToIP $free.Start
        $endIP = UInt32ToIP $free.End
        Get-CidrsFromRange -startIP $startIP -endIP $endIP
    }

    return $freeCIDRs | ForEach-Object { $_ }
}

function GenerateVirtualNetworkInfo {
    param ( [object]$subscription )

    foreach ($d in @("$OutputFolder\subscriptions", "$OutputFolder\virtualnetworks")) {
        if (-not (Test-Path $d -PathType Container)) {
            New-Item -Path $d -ItemType Directory | Out-Null
        }
    }

    try {
        WriteLog -Type 1 -Message "Gathering information on virtual networks in the subscription $($subscription.Name)"
        $virtualNetworks = Get-AzVirtualNetwork -ErrorAction SilentlyContinue
        $subFile = "$OutputFolder\subscriptions\$(FormatName -Name $subscription.Name).md"

        if ($virtualNetworks -and $virtualNetworks.Count -gt 0) {
            "## Virtual Networks"                                                          >> $subFile
            "The following virtual networks have been identified in the subscription **$($subscription.Name)**:" >> $subFile
            "" >> $subFile
            "| **Name** | **Resource Group** | **Location** | **Address Spaces** | **Details** |" >> $subFile
            "|----------|-------------------|--------------|---------------------|-------------|"  >> $subFile

            foreach ($vnet in $virtualNetworks) {
                $subSafe = FormatName -Name $subscription.Name
                $rgSafe = FormatName -Name $vnet.ResourceGroupName
                $vnSafe = FormatName -Name $vnet.Name
                $vnFile = "$OutputFolder\virtualnetworks\$subSafe-$rgSafe-$vnSafe.md"

                $addrSpaces = $vnet.AddressSpace.AddressPrefixes -join ', '

                "| $($vnet.Name) | $($vnet.ResourceGroupName) | $($vnet.Location) | $addrSpaces | [View](../virtualnetworks/$subSafe-$rgSafe-$vnSafe.md) |" >> $subFile

                "### Virtual Network - $($vnet.Name)"    >  $vnFile
                ""                                      >> $vnFile
                "---"                                   >> $vnFile
              

                "### Basic Information"                   >> $vnFile
                ' '                                     >> $vmFileName
                "| **Name** | **Resource Group** | **Location** | **Address Spaces** |" >> $vnFile
                "|----------|-------------------|--------------|---------------------|" >> $vnFile
                "| $($vnet.Name) | $($vnet.ResourceGroupName) | $($vnet.Location) | $addrSpaces |" >> $vnFile
                "" >> $vnFile

                # Used Subnets
                "### Used Subnets"                      >> $vnFile
                ""                                      >> $vnFile
                "---"                                   >> $vnFile
                "| **Subnet** | **Address Prefixes** | **NSG** |" >> $vnFile
                "|-----------|-----------------------|--------|"  >> $vnFile

                foreach ($sub in $vnet.Subnets) {
                    $prefix = $sub.AddressPrefix -join ', '
                    $nsg = if ($sub.NetworkSecurityGroup) { ($sub.NetworkSecurityGroup.Id -split '/')[8] } else { '—' }
                    "| $($sub.Name) | $prefix | $nsg |" >> $vnFile
                }

                # ---------- Free IP Blocks ----------
                "### Free IP Blocks" >> $vnFile
                ""                                      >> $vnFile
                "---"                                   >> $vnFile
                $subnetCidrs = foreach ($s in $vnet.Subnets) {
                    if ($s.AddressPrefix) { $s.AddressPrefix }
                    elseif ($s.AddressPrefixes) { $s.AddressPrefixes }
                }

                $freeBlocks = @()
                foreach ($addrSpace in $vnet.AddressSpace.AddressPrefixes) {
                    $freeBlocks += GetFreeCidrs -vnetCidr $addrSpace -subnetCidrs $subnetCidrs
                }

                $freeBlocks = $freeBlocks | Sort-Object -Unique

                if ($freeBlocks.Count -gt 0) {
                    "- $($freeBlocks -join ', ')" >> $vnFile
                }
                else {
                    "- None" >> $vnFile
                }

                "" >> $vnFile
            }
        }
    }
    catch {
        WriteLog -Type 3 -Message "There was a problem in gathering VNET info in subscription $($subscription.Name)"
        WriteLog -Type 3 $_
    }
}

function GenerateStorageAccountInfo {
    param ( [object]$subscription )

    # ------------------------------------------------------------------
    # Ensure output directories
    # ------------------------------------------------------------------
    foreach ($dir in @("$OutputFolder\subscriptions", "$OutputFolder\storageaccounts")) {
        if (-not (Test-Path $dir -PathType Container)) {
            New-Item -Path $dir -ItemType Directory | Out-Null
        }
    }

    try {
        WriteLog -Type 1 -Message "Gathering Storage Accounts in $($subscription.Name)"
        $sas = Get-AzStorageAccount -ErrorAction SilentlyContinue
        $subFile = "$OutputFolder\subscriptions\$(FormatName -Name $subscription.Name).md"

        if ($sas -and $sas.Count -gt 0) {
            # ---------------- Subscription‑level table ----------------
            "## Storage Accounts" >> $subFile
            ""                                      >> $saFile
            "---"                                   >> $saFile
            "The following storage accounts exist in **$($subscription.Name)**:" >> $subFile
            "" >> $subFile
            "| **Name** | **Resource Group** | **Location** | **SKU / Replication** | **Kind** | **Details** |" >> $subFile
            "|----------|-------------------|--------------|-----------------------|----------|-------------|" >> $subFile

            foreach ($sa in $sas) {
                # safe filenames
                $subSafe = FormatName -Name $subscription.Name
                $rgSafe = FormatName -Name $sa.ResourceGroupName
                $saSafe = FormatName -Name $sa.StorageAccountName
                $saFile = "$OutputFolder\storageaccounts\$subSafe-$rgSafe-$saSafe.md"

                $sku = $sa.Sku.Name          # e.g. Standard_LRS
                $kind = $sa.Kind              # StorageV2 / BlobStorage, etc.

                # summary row
                "| $($sa.StorageAccountName) | $($sa.ResourceGroupName) | $($sa.Location) | $sku | $kind | [View](../storageaccounts/$subSafe-$rgSafe-$saSafe.md) |" >> $subFile

                # ---------------- Storage Account Detail file ----------------
                "### Storage Account - $($sa.StorageAccountName)" >  $saFile
                "---" >> $saFile
                ""   >> $saFile

                # Basic Info table
                "### Basic Information" >> $saFile
                ""                                      >> $saFile
                "---"                                   >> $saFile
                "| **Name** | **Resource Group** | **Location** | **SKU / Replication** | **Kind** | **Access Tier** |" >> $saFile
                "|----------|-------------------|--------------|-----------------------|----------|-----------------|" >> $saFile
                "| $($sa.StorageAccountName) | $($sa.ResourceGroupName) | $($sa.Location) | $sku | $kind | $($sa.AccessTier) |" >> $saFile
                "" >> $saFile

                # Security / Networking
                "### Security & Networking" >> $saFile
                ""                                      >> $saFile
                "---"                                   >> $saFile
                $net = $sa.NetworkRuleSet
                "- **Secure Transfer Required:** $($sa.EnableHttpsTrafficOnly)" >> $saFile
                "- **Minimum TLS Version:** $($sa.MinimumTlsVersion)" >> $saFile
                "- **Public Access:** $($sa.PublicNetworkAccess)" >> $saFile
                "- **Default Network Action:** $($net.DefaultAction)" >> $saFile
                "- **Virtual Network Rules:** $($net.VirtualNetworkRules.Count)" >> $saFile
                "- **IP Rules:** $($net.IpRules.Count)" >> $saFile
                if ($sa.PrivateEndpointConnections.Count) {
                    "- **Private Endpoints: $($sa.PrivateEndpointConnections.Count)" >> $saFile
                }
                "" >> $saFile

                # Containers (Blob service)
                "### Blob Containers" >> $saFile
                ""                                      >> $saFile
                "---"                                   >> $saFile
                try {
                    $ctx = $sa.Context
                    $containers = Get-AzStorageContainer -Context $ctx -ErrorAction Stop
                    if ($containers) {
                        "| **Container** | **Public Access** |" >> $saFile
                        "|--------------|------------------|" >> $saFile
                        foreach ($c in $containers) {
                            "| $($c.Name) | $($c.PublicAccess) |" >> $saFile
                        }
                    }
                    else {
                        "- No containers found." >> $saFile
                    }
                }
                catch {
                    "- Unable to enumerate containers (permissions)." >> $saFile
                }
                "" >> $saFile

                # File Shares
                "### File Shares" >> $saFile
                ""                                      >> $saFile
                "---"                                   >> $saFile
                try {
                    if (-not $ctx) { $ctx = $sa.Context }
                    $shares = Get-AzStorageShare -Context $ctx -ErrorAction Stop
                    if ($shares) {
                        "| **Share** | **Quota GB** |" >> $saFile
                        "|-----------|-------------|" >> $saFile
                        foreach ($sh in $shares) {
                            "| $($sh.Name) | $($sh.Quota) |" >> $saFile
                        }
                    }
                    else {
                        "- No file shares found." >> $saFile
                    }
                }
                catch {
                    "- Unable to enumerate file shares (permissions)." >> $saFile
                }
                "" >> $saFile

                # Tags
                "### Tags" >> $saFile
                ""                                      >> $saFile
                "---"                                   >> $saFile
                if ($sa.Tags) {
                    "| Tag | Value |" >> $saFile
                    "|-----|-------|" >> $saFile
                    foreach ($tag in $sa.Tags.GetEnumerator()) {
                        "| $($tag.Key) | $($tag.Value) |" >> $saFile
                    }
                }
                else {
                    "- No tags." >> $saFile
                }
                "" >> $saFile
            } # end foreach storage account
        }
        else {
            WriteLog -Type 2 -Message "No storage accounts in $($subscription.Name)"
        }
    }
    catch {
        WriteLog -Type 3 -Message "Problem gathering storage accounts in $($subscription.Name): $_"
    }
}

function GenerateSqlServerInfo {
    param ( [object]$subscription )

    # Ensure output dirs
    foreach ($d in @("$OutputFolder\subscriptions", "$OutputFolder\sqlservers")) {
        if (-not (Test-Path $d -PathType Container)) {
            New-Item -Path $d -ItemType Directory | Out-Null
        }
    }

    try {
        WriteLog -Type 1 -Message "Gathering SQL Servers in $($subscription.Name)"
        $sqlServers = Get-AzSqlServer -ErrorAction SilentlyContinue
        $subFile = "$OutputFolder\subscriptions\$(FormatName -Name $subscription.Name).md"

        if ($sqlServers -and $sqlServers.Count -gt 0) {

            # ----- Subscription summary table -----
            "## SQL Servers" >> $subFile
            "---" >> $srvFile
            "" >> $srvFile

            "The following SQL Servers exist in **$($subscription.Name)**:" >> $subFile
            "" >> $subFile
            "| **Server** | **Resource Group** | **Location** | **Version** | **DB Count** | **Details** |" >> $subFile
            "|------------|-------------------|--------------|-------------|-------------|-------------|" >> $subFile

            foreach ($srv in $sqlServers) {
                $subSafe = FormatName -Name $subscription.Name
                $rgSafe = FormatName -Name $srv.ResourceGroupName
                $svSafe = FormatName -Name $srv.ServerName
                $srvFile = "$OutputFolder\sqlservers\$subSafe-$rgSafe-$svSafe.md"

                # Databases on this server
                $dbs = Get-AzSqlDatabase -ServerName $srv.ServerName -ResourceGroupName $srv.ResourceGroupName -ErrorAction SilentlyContinue
                $dbCount = if ($dbs) { $dbs.Count } else { 0 }

                # Summary row
                "| $($srv.ServerName) | $($srv.ResourceGroupName) | $($srv.Location) | $($srv.Version) | $dbCount | [View](../sqlservers/$subSafe-$rgSafe-$svSafe.md) |" >> $subFile

                # ----- Server detail file -----
                "### SQL Server - $($srv.ServerName)" >  $srvFile
                "---" >> $srvFile
                "" >> $srvFile

                # Basic info
                "### Basic Information" >> $srvFile
                "---" >> $srvFile
                "" >> $srvFile

                "| **Server** | **Resource Group** | **Location** | **Version** | **Admin Login** | **Public Network** |" >> $srvFile
                "|------------|-------------------|--------------|-------------|-----------------|--------------------|" >> $srvFile
                "| $($srv.ServerName) | $($srv.ResourceGroupName) | $($srv.Location) | $($srv.Version) | $($srv.AdministratorLogin) | $($srv.PublicNetworkAccess) |" >> $srvFile
                "" >> $srvFile

                # Databases table
                "### Databases" >> $srvFile
                "---" >> $srvFile
                "" >> $srvFile

                if ($dbs) {
                    "| **Database** | **Edition/Tier** | **Compute (DTU/vCore)** | **Max Size GB** | **Status** |" >> $srvFile
                    "|--------------|------------------|------------------------|-----------------|-----------|" >> $srvFile
                    foreach ($db in $dbs | Where-Object { $_.DatabaseName -ne "master" }) {
                        $tier = $db.Edition
                        $compute = if ($db.CurrentServiceObjectiveName) { $db.CurrentServiceObjectiveName } else { "-" }
                        "| $($db.DatabaseName) | $tier | $compute | $([math]::Round($db.MaxSizeBytes/1GB)) | $($db.Status) |" >> $srvFile
                    }
                }
                else {
                    "- No user databases found." >> $srvFile
                }
                "" >> $srvFile

                # Firewall rules
                "### Firewall Rules" >> $srvFile
                "---" >> $srvFile
                "" >> $srvFile

                $fwRules = Get-AzSqlServerFirewallRule -ResourceGroupName $srv.ResourceGroupName -ServerName $srv.ServerName -ErrorAction SilentlyContinue
                if ($fwRules) {
                    "| **Rule** | **Start IP** | **End IP** |" >> $srvFile
                    "|----------|-------------|------------|" >> $srvFile
                    foreach ($fw in $fwRules) {
                        "| $($fw.FirewallRuleName) | $($fw.StartIpAddress) | $($fw.EndIpAddress) |" >> $srvFile
                    }
                }
                else {
                    "- No firewall rules configured." >> $srvFile
                }
                "" >> $srvFile

                # Private endpoints
                $peCount = $srv.PrivateEndpointConnections.Count
                "### Networking" >> $srvFile
                "---" >> $srvFile
                "" >> $srvFile

                "- **Private Endpoints:** $peCount" >> $srvFile
                "" >> $srvFile

                # Tags
                "### Tags" >> $srvFile
                "---" >> $srvFile
                "" >> $srvFile

                if ($srv.Tags) {
                    "| Tag | Value |" >> $srvFile
                    "|-----|-------|" >> $srvFile
                    foreach ($tag in $srv.Tags.GetEnumerator()) {
                        "| $($tag.Key) | $($tag.Value) |" >> $srvFile
                    }
                }
                else {
                    "- No tags." >> $srvFile
                }
                "" >> $srvFile
            } # end foreach server
        }
        else {
            WriteLog -Type 2 -Message "No SQL Servers in $($subscription.Name)"
        }
    }
    catch {
        WriteLog -Type 3 -Message "Problem gathering SQL Servers in $($subscription.Name): $_"
    }
}

function GenerateAppServiceInfo {
    param ( [object]$subscription )

    # Ensure dirs
    foreach ($d in @("$OutputFolder\subscriptions", "$OutputFolder\appservices")) {
        if (-not (Test-Path $d -PathType Container)) {
            New-Item -Path $d -ItemType Directory | Out-Null
        }
    }

    try {
        WriteLog -Type 1 -Message "Gathering App Services in $($subscription.Name)"
        $apps = Get-AzWebApp -ErrorAction SilentlyContinue
        $subFile = "$OutputFolder\subscriptions\$(FormatName -Name $subscription.Name).md"

        if ($apps -and $apps.Count -gt 0) {
            # summary‑table header
            "## App Services & Function Apps" >> $subFile
            "The following App Services (Web/Function apps) exist in **$($subscription.Name)**:" >> $subFile
            "" >> $subFile
            "| **App** | **Resource Group** | **Location** | **Kind** | **Plan SKU** | **Details** |" >> $subFile
            "|---------|-------------------|--------------|----------|--------------|-------------|" >> $subFile

            # ----------------------  LOOP over $apps  ----------------------
            foreach ($app in $apps) {
                # ← fixed: use $apps, not $appServices
                $rg = $app.ResourceGroup
                if (-not $rg) {
                    WriteLog -Type 2 -Message "Skipping app '$($app.Name)' due to missing Resource Group"
                    continue
                }

                # plan & sku
                $planName = $app.ServerFarmId.Split('/')[-1]
                $plan = Get-AzAppServicePlan -Name $planName -ResourceGroupName $rg -ErrorAction SilentlyContinue
                $planSku = if ($plan) { $plan.Sku.Name } else { "-" }

                # build filenames
                $subSafe = FormatName -Name $subscription.Name
                $rgSafe = FormatName -Name $rg
                $appSafe = FormatName -Name $app.Name
                $appFile = "$OutputFolder\appservices\$subSafe-$rgSafe-$appSafe.md"

                # add row to summary table
                "| $($app.Name) | $rg | $($app.Location) | $($app.Kind) | $planSku | [View](../appservices/$subSafe-$rgSafe-$appSafe.md) |" >> $subFile

                # ---------------- file for each app ----------------
                "### App Service - $($app.Name)" >  $appFile
                "---" >> $appFile
                ""   >> $appFile

                # basic info
                "### Basic Information" >> $appFile
                "---" >> $appFile
                ""   >> $appFile
                "| **App** | **Resource Group** | **Location** | **Kind** | **Plan** | **Plan SKU** |" >> $appFile
                "|---------|-------------------|--------------|----------|----------|--------------|" >> $appFile
                "| $($app.Name) | $rg | $($app.Location) | $($app.Kind) | $planName | $planSku |" >> $appFile
                "" >> $appFile

                # configuration highlights
                $config = Get-AzWebApp -ResourceGroupName $rg -Name $app.Name -ErrorAction SilentlyContinue
                $runtimeStack = if ($config.SiteConfig.LinuxFxVersion) {
                    $config.SiteConfig.LinuxFxVersion
                }
                elseif ($config.SiteConfig.NetFrameworkVersion) {
                    $config.SiteConfig.NetFrameworkVersion
                }
                else { "-" }

                "### Configuration Highlights" >> $appFile
                "---" >> $appFile
                ""   >> $appFile
                "- **HTTPS Only:** $($config.HttpsOnly)" >> $appFile
                "- **Always On:** $($config.SiteConfig.AlwaysOn)" >> $appFile
                "- **Runtime Stack:** $runtimeStack" >> $appFile
                "- **FTPS State:** $($config.SiteConfig.FtpsState)" >> $appFile
                "" >> $appFile

                # slots
                $slots = Get-AzWebAppSlot -Name $app.Name -ResourceGroupName $rg -ErrorAction SilentlyContinue
                "### Deployment Slots" >> $appFile
                "---" >> $appFile
                ""   >> $appFile
                if ($slots) {
                    "| **Slot** | **Traffic %** | **Enabled** |" >> $appFile
                    "|----------|--------------|-------------|" >> $appFile
                    foreach ($s in $slots) {
                        "| $($s.Name) | $($s.TrafficWeight) | $($s.Enabled) |" >> $appFile
                    }
                }
                else {
                    "- No deployment slots." >> $appFile
                }
                "" >> $appFile

                # tags
                "### Tags" >> $appFile
                "---" >> $appFile
                ""   >> $appFile
                if ($app.Tags) {
                    "| Tag | Value |" >> $appFile
                    "|-----|-------|" >> $appFile
                    foreach ($tag in $app.Tags.GetEnumerator()) {
                        "| $($tag.Key) | $($tag.Value) |" >> $appFile
                    }
                }
                else {
                    "- No tags." >> $appFile
                }
                "" >> $appFile
            } # end foreach $apps
        }
        else {
            WriteLog -Type 2 -Message "No App Services or Function Apps in $($subscription.Name)"
        }
    }
    catch {
        WriteLog -Type 3 -Message "Problem gathering App Services in $($subscription.Name): $_"
    }
}

function GenerateKeyVaultInfo {
    param ( [object]$subscription )

    # Ensure output folders
    foreach ($d in @("$OutputFolder\subscriptions", "$OutputFolder\keyvaults")) {
        if (-not (Test-Path $d -PathType Container)) {
            New-Item -Path $d -ItemType Directory | Out-Null
        }
    }

    try {
        WriteLog -Type 1 -Message "Gathering Key Vaults in $($subscription.Name)"
        $kvs = Get-AzKeyVault -ErrorAction SilentlyContinue
        $subFile = "$OutputFolder\subscriptions\$(FormatName -Name $subscription.Name).md"

        if ($kvs -and $kvs.Count -gt 0) {

            # ---------- Subscription summary table ----------
            "## Key Vaults" >> $subFile
            "" >> $subFile
            "The following Key Vaults exist in **$($subscription.Name)**:" >> $subFile
            "" >> $subFile
            "| **Vault** | **Resource Group** | **Location** | **Soft Delete** | **RBAC Enabled** | **Details** |" >> $subFile
            "|-----------|-------------------|--------------|-----------------|------------------|-------------|" >> $subFile

            foreach ($kv in $kvs) {
                $subSafe = FormatName -Name $subscription.Name
                $rgSafe = FormatName -Name $kv.ResourceGroupName
                $kvSafe = FormatName -Name $kv.VaultName
                $kvFile = "$OutputFolder\keyvaults\$subSafe-$rgSafe-$kvSafe.md"

                # Add summary row
                "| $($kv.VaultName) | $($kv.ResourceGroupName) | $($kv.Location) | $($kv.EnableSoftDelete) | $($kv.EnableRbacAuthorization) | [View](../keyvaults/$subSafe-$rgSafe-$kvSafe.md) |" >> $subFile

                # ---------- Vault detail file ----------
                "## Key Vault - $($kv.VaultName)" >  $kvFile
                "---" >> $kvFile
                ""   >> $kvFile

                # Basic info
                "### Basic Information" >> $kvFile
                "---" >> $kvFile
                ""   >> $kvFile
                "| **Vault** | **Resource Group** | **Location** | **SKU** | **Softdelete** | **Purge Protection** | **RBAC Enabled** |" >> $kvFile
                "|-----------|-------------------|--------------|---------|-----------------|----------------------|------------------|" >> $kvFile
                "| $($kv.VaultName) | $($kv.ResourceGroupName) | $($kv.Location) | $($kv.Sku.Name) | $($kv.EnableSoftDelete) | $($kv.EnablePurgeProtection) | $($kv.EnableRbacAuthorization) |" >> $kvFile
                "" >> $kvFile

                # Networking
                "### Networking" >> $kvFile
                "---" >> $kvFile
                "" >> $kvFile

                if ($kv.NetworkAcls) {
                    "- **Public Network Access:** $($kv.PublicNetworkAccess)" >> $kvFile
                    "- **Default Action:** $($kv.NetworkAcls.DefaultAction)" >> $kvFile
                    "- **Virtual Network Rules:** $($kv.NetworkAcls.VirtualNetworkRules.Count)" >> $kvFile
                    "- **IP Rules:** $($kv.NetworkAcls.IpRules.Count)" >> $kvFile
                }
                else {
                    "- **Public Network Access:** Unknown (no permission or not configured)" >> $kvFile
                    "- **Default Action:** Unknown" >> $kvFile
                    "- **Virtual Network Rules:** Unknown" >> $kvFile
                    "- **IP Rules:** Unknown" >> $kvFile
                }
                "" >> $kvFile

                # Object counts
                "### Object Counts" >> $kvFile
                "---" >> $kvFile
                ""   >> $kvFile
                try {
                    $keyCount = (Get-AzKeyVaultKey         -VaultName $kv.VaultName -ErrorAction Stop).Count
                    $secretCount = (Get-AzKeyVaultSecret      -VaultName $kv.VaultName -ErrorAction Stop).Count
                    $certCount = (Get-AzKeyVaultCertificate -VaultName $kv.VaultName -ErrorAction Stop).Count
                }
                catch {
                    $keyCount = '?'
                    $secretCount = '?'
                    $certCount = '?'
                }
                "| **Keys** | **Secrets** | **Certificates** |" >> $kvFile
                "|----------|-------------|------------------|" >> $kvFile
                "| $keyCount | $secretCount | $certCount |"    >> $kvFile
                "" >> $kvFile

                # Tags
                "### Tags" >> $kvFile
                "---" >> $kvFile
                ""   >> $kvFile
                if ($kv.Tags) {
                    "| Tag | Value |" >> $kvFile
                    "|-----|-------|" >> $kvFile
                    foreach ($tag in $kv.Tags.GetEnumerator()) {
                        "| $($tag.Key) | $($tag.Value) |" >> $kvFile
                    }
                }
                else {
                    "- No tags." >> $kvFile
                }
                "" >> $kvFile
            } # end foreach kv
        }
        else {
            WriteLog -Type 2 -Message "No Key Vaults in $($subscription.Name)"
        }
    }
    catch {
        WriteLog -Type 3 -Message "Problem gathering Key Vaults in $($subscription.Name): $_"
    }
}


function GenerateLoadBalancerInfo {
    param ( [object]$subscription )

    foreach ($d in @("$OutputFolder\subscriptions", "$OutputFolder\loadbalancers")) {
        if (-not (Test-Path $d -PathType Container)) { New-Item -Path $d -ItemType Directory | Out-Null }
    }

    try {
        WriteLog -Type 1 -Message "Gathering Load Balancers in $($subscription.Name)"
        $lbs = Get-AzLoadBalancer -ErrorAction SilentlyContinue
        $subFile = "$OutputFolder\subscriptions\$(FormatName -Name $subscription.Name).md"

        if ($lbs) {
            "## Load Balancers" >> $subFile
            "The following Load Balancers exist in **$($subscription.Name)**:" >> $subFile
            "" >> $subFile
            "| **LB** | **Resource Group** | **Location** | **SKU** | **Tier** |" >> $subFile
            "|--------|--------------------|--------------|---------|----------|" >> $subFile

            foreach ($lb in $lbs) {
                $subSafe = FormatName -Name $subscription.Name
                $rgSafe = FormatName -Name $lb.ResourceGroupName
                $lbSafe = FormatName -Name $lb.Name
                $lbFile = "$OutputFolder\loadbalancers\$subSafe-$rgSafe-$lbSafe.md"

                # counts / lists
                $feIps = @()
                foreach ($fe in $lb.FrontendIpConfigurations) {
                    if ($fe.PrivateIpAddress) { $feIps += $fe.PrivateIpAddress }
                    elseif ($fe.PublicIpAddress.Id) { $feIps += ($fe.PublicIpAddress.Id -split '/')[8] }
                }
                $feList = ($feIps -join ', ')
                $sku = $lb.Sku.Name
                $tier = $lb.Sku.Tier

                # summary row
                "| $($lb.Name) | $($lb.ResourceGroupName) | $($lb.Location) | $($lb.Sku.Name) | $($lb.Sku.Tier) | [View](../loadbalancers/$subSafe-$rgSafe-$lbSafe.md) |" >> $subFile


                # $kvFile = "$OutputFolder\keyvaults\$subSafe-$rgSafe-$kvSafe.md"

                # # Add summary row
                # "| $($kv.VaultName) | $($kv.ResourceGroupName) | $($kv.Location) | $($kv.EnableSoftDelete) | $($kv.EnableRbacAuthorization) | [View](../keyvaults/$subSafe-$rgSafe-$kvSafe.md) |" >> $subFile

                # detail file
                "### Load Balancer - $($lb.Name)"  >  $lbFile
                "---" >> $lbFile
                ""   >> $lbFile

                "### Basic Information" >> $lbFile
                "---" >> $lbFile
                ""   >> $lbFile
                "| **Name** | **Resource Group** | **Location** | **SKU** | **Tier** | " >> $lbFile
                "|----------|--------------------|--------------|---------|----------| " >> $lbFile
                "| $($lb.Name) | $($lb.ResourceGroupName) | $($lb.Location) | $($lb.Sku.Name) | $($lb.Sku.Tier) |" >> $lbFile
                "" >> $lbFile

                # Backend pools & rules
                "### Backend Pools & Rules" >> $lbFile
                "---" >> $lbFile
                ""   >> $lbFile
                "| **Backend Pool** | **IP Count** |" >> $lbFile
                "|-----------------|-------------|" >> $lbFile
                foreach ($pool in $lb.BackendAddressPools) {
                    $addrCount = $pool.BackendIPConfigurations.Count + $pool.LoadBalancerBackendAddresses.Count
                    "| $($pool.Name) | $addrCount |" >> $lbFile
                }
                "" >> $lbFile

                "### Load Balancing Rules" >> $lbFile
                "---" >> $lbFile
                ""   >> $lbFile
                "| **Rule** | **Protocol** | **Port** | **Backend Port** | **Probe** |" >> $lbFile
                "|----------|--------------|----------|------------------|-----------|" >> $lbFile
                foreach ($rule in $lb.LoadBalancingRules) {
                    "| $($rule.Name) | $($rule.Protocol) | $($rule.FrontendPort) | $($rule.BackendPort) | $($rule.Probe.Id -split '/')[8] |" >> $lbFile
                }
                "" >> $lbFile

                # Tags
                "### Tags" >> $lbFile
                "---" >> $lbFile
                ""   >> $lbFile
                if ($lb.Tags) {
                    "| Tag | Value |" >> $lbFile
                    "|-----|-------|" >> $lbFile
                    foreach ($tag in $lb.Tags.GetEnumerator()) {
                        "| $($tag.Key) | $($tag.Value) |" >> $lbFile
                    }
                }
                else { "- No tags." >> $lbFile }
                "" >> $lbFile
            }
        }
    }
    catch {
        WriteLog -Type 3 -Message "Problem gathering Load Balancers in $($subscription.Name): $_"
    }
}

function GenerateAppGatewayInfo {
    param ( [object]$subscription )

    foreach ($d in @("$OutputFolder\subscriptions", "$OutputFolder\appgateways")) {
        if (-not (Test-Path $d -PathType Container)) { New-Item -Path $d -ItemType Directory | Out-Null }
    }

    try {
        WriteLog -Type 1 -Message "Gathering Application Gateways in $($subscription.Name)"
        $ags = Get-AzApplicationGateway -ErrorAction SilentlyContinue
        $subFile = "$OutputFolder\subscriptions\$(FormatName -Name $subscription.Name).md"

        if ($ags) {
            "## Application Gateways" >> $subFile
            "---" >> $agFile
            ""   >> $agFile
            "The following App Gateways exist in **$($subscription.Name)**:" >> $subFile
            "" >> $subFile
            "| **Gateway** | **Resource Group** | **Location** | **SKU | Tier**  |" >> $subFile
            "|-------------|--------------------|--------------|-------|---------|" >> $subFile

            foreach ($ag in $ags) {
                $subSafe = FormatName -Name $subscription.Name
                $rgSafe = FormatName -Name $ag.ResourceGroupName
                $agSafe = FormatName -Name $ag.Name
                $agFile = "$OutputFolder\appgateways\$subSafe-$rgSafe-$agSafe.md"

                # fields
                $tier = $ag.Sku.Tier
                $sku = $ag.Sku.Name
                $waf = if ($ag.WebApplicationFirewallConfiguration -and $ag.WebApplicationFirewallConfiguration.Enabled) { "Enabled" } else { "Disabled" }
                $feIps = ($ag.FrontendIPConfigurations | ForEach-Object {
                        if ($_.PrivateIPAddress) { $_.PrivateIPAddress } elseif ($_.PublicIPAddress.Id) { ($_.PublicIPAddress.Id -split '/')[8] }
                    }) -join ', '

                # summary row
                "| $($ag.Name) | $($ag.ResourceGroupName) | $($ag.Location) | $($ag.Sku.Tier) | [View](../appgateways/$subSafe-$rgSafe-$agSafe.md) |" >> $subFile

                # detail file
                "## Application Gateway - $($ag.Name)" >  $agFile
                "---" >> $agFile
                ""   >> $agFile

                "### Basic Information" >> $agFile
                "---" >> $agFile
                ""   >> $agFile
                "| **Name** | **Resource Group** | **Location** | **SKU** | **Tier** |" >> $agFile
                "|----------|--------------------|--------------|---------|----------||" >> $agFile
                "| $($ag.Name) | $($ag.ResourceGroupName) | $($ag.Location) |$($ag.Sku.Name) | $($ag.Sku.Tier) |" >> $agFile
                "" >> $agFile

                # Listeners & Rules
                "### Listeners" >> $agFile
                "---" >> $agFile
                ""   >> $agFile
                "| **Listener** | **Protocol** | **Port** | **Host Names** |" >> $agFile
                "|--------------|-------------|-----------|----------------|" >> $agFile
                foreach ($lst in $ag.HttpListeners) {
                    "| $($lst.Name) | $($lst.Protocol) | $($lst.FrontendPort -replace '.*/','') | $([string]::Join(',', $lst.HostName, $lst.HostNames)) |" >> $agFile
                }
                "" >> $agFile

                "### Routing Rules" >> $agFile
                "---" >> $agFile
                ""   >> $agFile
                "| **Rule** | **Rule Type** | **Listener** | **Backend Pool** |" >> $agFile
                "|----------|---------------|--------------|------------------|" >> $agFile
                foreach ($rule in $ag.RequestRoutingRules) {
                    $listener = ($rule.HttpListener.Id -split '/')[10]
                    $pool = if ($rule.BackendAddressPool) { ($rule.BackendAddressPool.Id -split '/')[10] } else { "-" }
                    "| $($rule.Name) | $($rule.RuleType) | $listener | $pool |" >> $agFile
                }
                "" >> $agFile

                # Tags
                "### Tags" >> $agFile
                "---" >> $agFile
                ""   >> $agFile
                if ($ag.Tags) {
                    "| Tag | Value |" >> $agFile
                    "|-----|-------|" >> $agFile
                    foreach ($tag in $ag.Tags.GetEnumerator()) {
                        "| $($tag.Key) | $($tag.Value) |" >> $agFile
                    }
                }
                else { "- No tags." >> $agFile }
                "" >> $agFile
            }
        }
    }
    catch {
        WriteLog -Type 3 -Message "Problem gathering App Gateways in $($subscription.Name): $_"
    }
}

function GenerateRecoveryVaultInfo {
    param ( [object]$subscription )

    # Ensure folders
    foreach ($d in @("$OutputFolder\subscriptions", "$OutputFolder\recoveryvaults")) {
        if (-not (Test-Path $d -PathType Container)) {
            New-Item -Path $d -ItemType Directory | Out-Null
        }
    }

    try {
        WriteLog -Type 1 -Message "Gathering Recovery Services Vaults in $($subscription.Name)"
        
        # Get Recovery Services Vaults in the subscription
        $vaults = Get-AzRecoveryServicesVault -ErrorAction SilentlyContinue

        $subFile = "$OutputFolder\subscriptions\$(FormatName -Name $subscription.Name).md"

        if ($vaults -and $vaults.Count -gt 0) {

            # Summary table header in subscription file
            "## Recovery Services Vaults" >> $subFile
            "---" >> $subFile
            "" >> $subFile
            "The following Recovery Services Vaults exist in **$($subscription.Name)**:" >> $subFile
            "" >> $subFile
            "| **Vault** | **Resource Group** | **Location** | **SKU** | **Backup Storage Type** | **Details** |" >> $subFile
            "|-----------|-------------------|--------------|---------|------------------------|-------------|" >> $subFile

            foreach ($vault in $vaults) {
                $subSafe = FormatName -Name $subscription.Name
                $rgSafe = FormatName -Name $vault.ResourceGroupName
                $vaultSafe = FormatName -Name $vault.Name
                $vaultFile = "$OutputFolder\recoveryvaults\$subSafe-$rgSafe-$vaultSafe.md"

                # Add summary row to subscription file
                "| $($vault.Name) | $($vault.ResourceGroupName) | $($vault.Location) | $($vault.Sku) | $($vault.Properties.BackupStorageType) | [View](../recoveryvaults/$subSafe-$rgSafe-$vaultSafe.md) |" >> $subFile

                # Create detailed vault file
                "### Recovery Services Vault - $($vault.Name)" > $vaultFile
                "---" >> $vaultFile
                "" >> $vaultFile

                # Basic Information
                "### Basic Information" >> $vaultFile
                "---" >> $vaultFile
                "" >> $vaultFile
                "| **Vault** | **Resource Group** | **Location** | **SKU** | **Backup Storage Type** |" >> $vaultFile
                "|-----------|-------------------|--------------|---------|------------------------|" >> $vaultFile
                "| $($vault.Name) | $($vault.ResourceGroupName) | $($vault.Location) | $($vault.Sku) | $($vault.Properties.BackupStorageType) |" >> $vaultFile
                "" >> $vaultFile

                # Vault properties
                "### Vault Properties" >> $vaultFile
                "---" >> $vaultFile
                "" >> $vaultFile
                "- **Provisioning State:** $($vault.Properties.ProvisioningState)" >> $vaultFile
                "- **Encryption Status:** $($vault.Properties.Encryption.Status)" >> $vaultFile
                "- **Encryption Key Vault Resource ID:** $($vault.Properties.Encryption.KeyVaultResourceId)" >> $vaultFile
                "" >> $vaultFile

                # Tags
                "### Tags" >> $vaultFile
                "---" >> $vaultFile
                "" >> $vaultFile
                if ($vault.Tags) {
                    "| Tag | Value |" >> $vaultFile
                    "|-----|-------|" >> $vaultFile
                    foreach ($tag in $vault.Tags.GetEnumerator()) {
                        "| $($tag.Key) | $($tag.Value) |" >> $vaultFile
                    }
                }
                else {
                    "- No tags." >> $vaultFile
                }
                "" >> $vaultFile
            }
        }
        else {
            WriteLog -Type 2 -Message "No Recovery Services Vaults in $($subscription.Name)"
        }
    }
    catch {
        WriteLog -Type 3 -Message "Problem gathering Recovery Services Vaults in $($subscription.Name): $_"
    }
}

function GenerateHeader() {
    Param ( [string]$DefinitionType )

    if ($null -ne $Definitions."$DefinitionType".header) {
        [string]$creationGuide = "
## Introduction 
$($Definitions."$DefinitionType".header)
"
        return $creationGuide
    }
}

function GenerateCreationGuide() {
    Param ( [string]$DefinitionType )

    if ($null -ne $Definitions."$DefinitionType".creation_guide) {
        [string]$creationGuide = "
## Creation Guide 
$($Definitions."$DefinitionType".creation_guide)
"
        return $creationGuide
    }
}

function GenerateFooter() {
    Param ( [string]$DefinitionType )

    if ($null -ne $Definitions."$DefinitionType".footer) {
        return  $Definitions."$DefinitionType".footer
    }
}

function GenerateSupportInfo() {
    [string]$footer = "
## Support

For further support please contact,
- Deepak Venugopal (deepak.venugopal@akersolutions.com)
- Shamsher Khan B (shamsher.khan.b@akersolutions.com)
- Vitthal Naikare (Vitthal.Naikare@akersolutions.com)
- Pravin Jadhav (pravin.Jadhav2@akersolutions.com)
"

    $footer += "
## Document Info
This document was last updated on $([DateTime]::UtcNow.ToString('u').Replace('Z',' UTC'))    
"

    return $footer
}

function FormatName() {
    Param ( [string]$Name )
    $allowedCharacters = "[^a-zA-Z_0-9]" # anything that's not a-z, 0-9 or underscore
    return $Name.ToLower() -replace $allowedCharacters, ''
}

function WriteLog () {

    Param ( [byte]$Type, [string]$Message )

    $TimeStamp = Get-Date -Format "dd.MMM.yyyy HH:mm:ss"
    $Time = Get-Date -Format "HH:mm:ss"

    if ($Type -eq 1) {
        if ($VerboseLogging) { Write-Host "[INFO] - $Time - $Message" -ForegroundColor Green }
        $Global:LogFileData += "[INFO] - $TimeStamp - $Message"
        $Global:LogFileData += "`r`n"
    }
    if ($Type -eq 2) {
        if ($VerboseLogging) { Write-Host "[WARNING] - $Time - $Message" -ForegroundColor Yellow }
        $Global:LogFileData += "[WARNING] - $TimeStamp - $Message"
        $Global:LogFileData += "`r`n"
    }
    if ($Type -eq 3) {
        if ($VerboseLogging) { Write-Host "[ERROR] - $Time - $Message" -ForegroundColor Red }
        $Global:LogFileData += "[ERROR] - $TimeStamp - $Message"
        $Global:LogFileData += "`r`n"
    }
}

function Terminate () {
    WriteLog -Type 1 -Message "Script execution complete"
    WriteLog -Type 1 -Message "Stopping execution timer and calculating script run duration"
    $ExecutionTimer.Stop() <# --- Stops the timer to track the total execution time of the script --- #>
    $executionTime = $ExecutionTimer.Elapsed <# --- Calculate the total time taken for script execution --- #>
    WriteLog -Type 1 -Message "Script execution complete. Total execution time is $($executionTime.hours):$($executionTime.minutes):$($executionTime.seconds)"
    Exit
}

#endregion Script Methods	

#region Script Header

[string] $Global:LogFileData = "Execution Log - $ScriptName"
$Global:LogFileData += "`r`n"
$Global:LogFileData += "`r`n"

[string] $TimeStamp = Get-Date -Format "dd.MMM.yyyy HH:mm:ss"

WriteLog -Type 1 -Message "Script execution started at $TimeStamp by $(whoami) on $(hostname)"
WriteLog -Type 1 -Message "Gathering runtime information"
WriteLog -Type 1 -Message "ErrorActionPreference has been set to $ErrorActionPreference"
WriteLog -Type 1 -Message "Starting execution timer"
$ExecutionTimer = [Diagnostics.Stopwatch]::StartNew() <# --- Starts a timer to track the total execution time of the script --- #>

#endregion Script Header

#region Script Body

<# --- Validate runtime parameters --- #>
if ([string]::IsNullOrWhitespace($DefinitionsFile) -or [string]::IsNullOrWhitespace($OutputFolder)) {
    WriteLog -Type 3 -Message "Invalid definitions file specified. Specify a valid file."
    Terminate
}

<# --- Read definitions file --- #>
WriteLog -Type 1 -Message "Reading definitions file"
try {
    $Definitions = Get-Content .\definitions.yml | ConvertFrom-Yaml
    if ($null -eq $Definitions -or $Definitions.count -eq 0) {
        WriteLog -Type 3 -Message "Invalid definitions file specified. Specify a valid file."
        Terminate     
    }
}
catch {
    WriteLog -Type 3 -Message "Unable to read a valid definitions file"
    Terminate    
}

<# --- Create output folder if not present --- #>
if (-not(Test-Path $OutputFolder -PathType Container)) {
    WriteLog -Type 1 -Message "Creating output directory at $OutputFolder"
    New-Item -path $OutputFolder -ItemType Directory | Out-Null
}
else {
    WriteLog -Type 1 -Message "Purging output directory at $OutputFolder"
    Remove-Item $OutputFolder -Recurse -Force
    WriteLog -Type 1 -Message "Creating output directory at $OutputFolder"
    New-Item -path $OutputFolder -ItemType Directory | Out-Null
}

GatherBasicInfo
GatherManagementGroupInfo
GatherSubscriptionInfo

#endregion Script Body
        
#region Script Footer

WriteLog -Type 1 -Message "Script execution complete"
WriteLog -Type 1 -Message "Stopping execution timer and calculating script run duration"
$ExecutionTimer.Stop() <# --- Stops the timer to track the total execution time of the script --- #>
$executionTime = $ExecutionTimer.Elapsed <# --- Calculate the total time taken for script execution --- #>
WriteLog -Type 1 -Message "Script execution complete. Total execution time is $($executionTime.hours):$($executionTime.minutes):$($executionTime.seconds)"

if ($GenerateLogFile) {
    WriteLog -Type 1 -Message "Generating Execution Log"
    try {

        if (!(Test-Path -path $LogLocation)) { New-Item $LogLocation -Type Directory }

        $LogFile = Join-Path $LogLocation "$ScriptShortName.log"
        
        if (Test-Path -path $LogFile) { Remove-Item $LogFile }

        $Global:LogFileData > $LogFile
        WriteLog -Type 1 -Message "Execution Log saved as $LogFile"
    }
    catch {
        WriteLog -Type 3 -Message "There was a problem in saving the Execution Log"
        WriteLog -Type 3 $_
    }
}

#endregion Script Footer