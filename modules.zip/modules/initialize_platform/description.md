## Introduction

This module is used to initialize the tenant to support Infrastructure as Code deployments using OpenTofu. This module performs the following tasks,

- Creates a resource group to hold resources such as IAC state files, managed identities, etc.
- Creates a managed identity for platform governance
- Assigns the "Privileged Role Administrator" Entra ID role to the platform governance managed identity
- Assigns the "Owner" role to the Tenant Root Management Group to the platform governance managed identity
- Create a Global Administrative Unit. This will contain RBAC groups that provide RBAC to all subscriptions
- Creates a storage account that will store the state files
- Creates a storage container for storing state files for platform governance
- Create RBAC groups in Entra for providing Reader and Data Access to the storage account
- Map the Reader and Data Access security group created above into the Reader and Data Access role of the IAC storage account
