<!-- BEGIN_AUTOMATED_TF_DOCS_BLOCK -->
## Introduction

This module is used to onboard a new Azure Subscription to the Azure Landing Zone. This module performs the following tasks,

- ### Configure Administrative Units (configure\\_administrative\\_units.tf)
  - Create an Administrative Unit for each subscription. This will contain RBAC groups for the resources created inside this Subscription.

- ### Configure RBAC Roles & Security Groups (configure\\_rbac\\_groups.tf)
  - Create RBAC groups in Entra for each subscription and place it in the appropriate Administrative Unit
  - Map the RBAC groups to the appropriate roles for each subscription
  - Add members to the subscription specific RBAC groups

- ### Configure Managed Identities (configure\\_managed\\_identities.tf)
  - Create a managed identity for each subscription
  - Map the managed identity into the owner role of the respective subscription. This access is required to manage permissions and roles of underlying resources.
  - Create security group to host all Managed Identities
  - Add all managed identities to the security group created above
  - Map the security group containing all the managed identities to the "**Network Contributor**" role of all subscriptions. This access is required to create VNET peerings.
  - Provide Directory Reader role on the Tenant to all the managed identities
  - Provide Group Administrator role on the Tenant to all the managed identities. This resource assignment is used if the Entra Tenant is NOT licensed with a P1 or P2 license. The scope for this assignment is valid if "***entra\\_license\\_available***" is set to "***true***".
  - Provide Group Administrator role on the subscription specific AU to the subscription specific managed identity. This resource assignment is used if the Entra Tenant is licensed with a P1 or P2 license. The scope for this assignment is valid if "***entra\\_license\\_available***" is set to "***true***".
  - Map the managed identity into the Storage Blob Data Contributor role of the respective storage container
  - Map the managed identity into the Storage Account Key Operator Service role of the respective storage container
  - Add the managed identity of each subscription into the Reader and Data Access security group created above
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | 3.4.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.34.0 |
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_global_configuration"></a> [global\_configuration](#input\_global\_configuration) | (Required) The path to the global configuration yaml file | `string` | n/a | yes |
| <a name="input_managed_identity_security_group_name"></a> [managed\_identity\_security\_group\_name](#input\_managed\_identity\_security\_group\_name) | The name of the security group to host all the subscription based managed identitie. Defaults to 'glo-sub-managed-identities'. | `string` | `"glo-sub-managed-identities"` | no |
| <a name="input_subscriptions"></a> [subscriptions](#input\_subscriptions) | (Required) The path to the yaml file containing subscription specific information. Refer sample in the templates folder. | `string` | n/a | yes |
  ## Usage
  Basic usage of this module is as follows:
  ```hcl
  module "example" {
    	 source  = "<module-path>"
    
	 # Required variables
    	 global_configuration  = 
    	 subscriptions  = 
    
	 # Optional variables
    	 managed_identity_security_group_name  = "glo-sub-managed-identities"
  }
  ```

## Resources

| Name | Type |
|------|------|
| [azuread_administrative_unit.sub_au](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/resources/administrative_unit) | resource |
| [azuread_administrative_unit_role_member.sub_mid_au_groupadministrator_role_assignment](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/resources/administrative_unit_role_member) | resource |
| [azuread_directory_role.entra_directory_readers](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/resources/directory_role) | resource |
| [azuread_directory_role.entra_group_administrators](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/resources/directory_role) | resource |
| [azuread_directory_role_assignment.sub_mid_directoryreader_role_assignment](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/resources/directory_role_assignment) | resource |
| [azuread_directory_role_assignment.sub_mid_tenant_groupadministrator_role_assignment](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/resources/directory_role_assignment) | resource |
| [azuread_group.sub_mid_security_group](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/resources/group) | resource |
| [azuread_group.sub_rbac_group](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/resources/group) | resource |
| [azuread_group_member.sub_mid_data_reader_data_access_rbac_group_memberships](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/resources/group_member) | resource |
| [azuread_group_member.sub_mid_directoryreader_role_assignment](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/resources/group_member) | resource |
| [azuread_group_member.sub_rbac_group_members](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/resources/group_member) | resource |
| [azurerm_role_assignment.sub_mid_blobdatacontributor_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.sub_mid_keyoperator_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.sub_mid_network_contributor_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.sub_mid_owner_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.sub_rbac_group_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/role_assignment) | resource |
| [azurerm_user_assigned_identity.sub_mid](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/user_assigned_identity) | resource |
| [time_sleep.wait_for_sub_mid](https://registry.terraform.io/providers/hashicorp/time/latest/docs/resources/sleep) | resource |
| [azuread_administrative_unit.global_subscription_rbac_administrative_unit](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/data-sources/administrative_unit) | data source |
| [azuread_administrative_unit.sub_au](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/data-sources/administrative_unit) | data source |
| [azuread_group.iac_storage_account_reader](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/data-sources/group) | data source |
| [azuread_group.members](https://registry.terraform.io/providers/hashicorp/azuread/3.4.0/docs/data-sources/group) | data source |
| [azurerm_resource_group.iac_config_resource_group](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/resource_group) | data source |
| [azurerm_storage_container.container](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/storage_container) | data source |

## Support
For further support please contact,
- Deepak Venugopal (deepak.venugopal@akersolutions.com)
- Shamsher Khan B (shamsher.khan.b@akersolutions.com)
- Vitthal Naikare (Vitthal.Naikare@akersolutions.com)
<!-- END_AUTOMATED_TF_DOCS_BLOCK -->