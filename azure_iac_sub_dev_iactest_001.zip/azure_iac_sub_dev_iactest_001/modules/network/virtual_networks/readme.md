<!-- BEGIN_AUTOMATED_TF_DOCS_BLOCK -->

## Introduction

This IAC module is used to create Virtual Networks and associated configurations in Azure. It performs the following tasks:

- Creates Virtual Networks
- Creates Subnets
- Create Network Security Group
- Associate Network Security Group to Subnet
- Adds a delete lock on the Virtual Network
- Attach ddos protection plan to Virtual Network
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.34.0 |
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_definitions"></a> [definitions](#input\_definitions) | (Required) The path to the yaml file containing virtual network definitions. Refer sample in the templates folder. | `string` | n/a | yes |
| <a name="input_global_configuration"></a> [global\_configuration](#input\_global\_configuration) | (Required) The path to the global configuration YAML file | `string` | n/a | yes |
| <a name="input_rg_dependency"></a> [rg\_dependency](#input\_rg\_dependency) | Dependency on resource group creation | `any` | n/a | yes |
  ## Usage
  Basic usage of this module is as follows:
  ```hcl
  module "example" {
    	 source  = "<module-path>"
    
	 # Required variables
    	 definitions  = 
    	 global_configuration  = 
    	 rg_dependency  = 
  }
  ```

## Resources

| Name | Type |
|------|------|
| [azurerm_management_lock.vnet_delete_lock](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/management_lock) | resource |
| [azurerm_network_security_group.nsg](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/network_security_group) | resource |
| [azurerm_subnet.subnet](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/subnet) | resource |
| [azurerm_subnet_network_security_group_association.nsg_assosiation](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/subnet_network_security_group_association) | resource |
| [azurerm_virtual_network.virtual_network](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/virtual_network) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/client_config) | data source |
| [azurerm_network_ddos_protection_plan.existing](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/network_ddos_protection_plan) | data source |
| [azurerm_resource_group.iac_vnet_resource_group](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/resource_group) | data source |

## Support
For further support please contact,
- Deepak Venugopal (deepak.venugopal@akersolutions.com)
- Shamsher Khan B (shamsher.khan.b@akersolutions.com)
- Vitthal Naikare (Vitthal.Naikare@akersolutions.com)
<!-- END_AUTOMATED_TF_DOCS_BLOCK -->