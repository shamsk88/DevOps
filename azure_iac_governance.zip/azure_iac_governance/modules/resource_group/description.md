## Introduction

This module is used to create resource groups. This module performs the following tasks,

- ### Create Resource Groups (create\_resource\_group.tf)
  - Create resource groups. The resource groups are created in the current subscription.

- ### Configure RBAC Roles & Security Groups (configure\_rbac\_groups.tf)
  - Create RBAC groups in Entra for the each resource group and place it in the appropriate Administrative Unit
  - Map the RBAC groups to the appropriate roles for each resource group
  - Add members to the resource group specific RBAC groups if specified

