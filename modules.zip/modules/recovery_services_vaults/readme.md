<!-- BEGIN_AUTOMATED_TF_DOCS_BLOCK -->
## Introduction

This IAC module is designed to create Azure Recovery Services Vaults (RSVs) and configure backup policies for various workloads. It simplifies the process of setting up backup and disaster recovery solutions in Azure. This module has the following features,

- **Recovery Services Vault Creation**: Automates the creation of secure Recovery Services Vaults to store backup data.
- **Backup Policy Configuration**:
  - Workload-specific policies for Azure services such as SAP and SQL.
  - Backup policies for Azure Virtual Machines.
- **Customizable Policies**: Define backup schedules and retention periods to meet organizational requirements.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_global_configuration"></a> [global\_configuration](#input\_global\_configuration) | (Required) The path to the global configuration YAML file | `string` | n/a | yes |
| <a name="input_rsvvault_definitions"></a> [rsvvault\_definitions](#input\_rsvvault\_definitions) | (Required) The path to the YAML file that contains the list of rsvvaults to be procesed | `string` | n/a | yes |
  ## Usage
  Basic usage of this module is as follows:
  ```hcl
  module "example" {
    	 source  = "<module-path>"
    
	 # Required variables
    	 global_configuration  = 
    	 rsvvault_definitions  = 
  }
  ```

## Resources

| Name | Type |
|------|------|
| [azurerm_backup_policy_vm.policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_policy_vm) | resource |
| [azurerm_backup_policy_vm_workload.workload_policy](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/backup_policy_vm_workload) | resource |
| [azurerm_recovery_services_vault.rsv](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/recovery_services_vault) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/client_config) | data source |
| [azurerm_resource_group.rsv_resource_group](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/data-sources/resource_group) | data source |

## Support
For further support please contact,
- Deepak Venugopal (deepak.venugopal@akersolutions.com)
- Shamsher Khan B (shamsher.khan.b@akersolutions.com)
- Vitthal Naikare (Vitthal.Naikare@akersolutions.com)
<!-- END_AUTOMATED_TF_DOCS_BLOCK -->