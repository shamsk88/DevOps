<!-- BEGIN_AUTOMATED_TF_DOCS_BLOCK -->
## Introduction

This module is used to initialize the tenant to support Infrastructure as Code deployments using OpenTofu. This module performs the following tasks,

- Creates a resource group to hold resources such as IAC state files, managed identities, etc.
- Creates a managed identity for platform governance
- Assigns the "Privileged Role Administrator" Entra ID role to the platform governance managed identity
- Assigns the "Owner" role to the Tenant Root Management Group to the platform governance managed identity
- Create a Global Administrative Unit. This will contain RBAC groups that provide RBAC to all subscriptions
- Creates a storage account that will store the state files
- Creates a storage container for storing state files for platform governance
- Create RBAC groups in Entra for providing Reader and Data Access to the storage account
- Map the Reader and Data Access security group created above into the Reader and Data Access role of the IAC storage account
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.34.0 |
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_global_configuration"></a> [global\_configuration](#input\_global\_configuration) | (Required) The path to the global configuration JSON file | `string` | n/a | yes |
| <a name="input_governance_managed_identity_name"></a> [governance\_managed\_identity\_name](#input\_governance\_managed\_identity\_name) | (Required) The name of the managed identity to be created for running governance pipelines | `string` | n/a | yes |
| <a name="input_iac_subscription"></a> [iac\_subscription](#input\_iac\_subscription) | (Required) The Id of the subscription hosting the IAC resources. Defaults to the value specified in the global configuration. | `string` | `null` | no |
| <a name="input_resource_group_location"></a> [resource\_group\_location](#input\_resource\_group\_location) | (Required) The location where the resource group is to be created. Defaults to the value specified in the global configuration. | `string` | `null` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | (Required) The name of the resource group to be created. Defaults to the value specified in the global configuration. | `string` | `null` | no |
| <a name="input_storage_account_name"></a> [storage\_account\_name](#input\_storage\_account\_name) | (Required) The name of the storage account to be created. Defaults to the value specified in the global configuration. | `string` | `null` | no |
| <a name="input_storage_account_replication_type"></a> [storage\_account\_replication\_type](#input\_storage\_account\_replication\_type) | (Required) Defines the type of replication to use for this storage account. Valid options are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS. Defaults to LRS. | `string` | `"LRS"` | no |
| <a name="input_storage_account_tier"></a> [storage\_account\_tier](#input\_storage\_account\_tier) | (Required) Defines the Tier to use for this storage account. Valid options are Standard and Premium. Defaults to Standard. | `string` | `"Standard"` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | Tags to apply on all resources | `map(string)` | n/a | yes |
  ## Usage
  Basic usage of this module is as follows:
  ```hcl
  module "example" {
    	 source  = "<module-path>"
    
	 # Required variables
    	 global_configuration  = 
    	 governance_managed_identity_name  = 
    	 tags  = 
    
	 # Optional variables
    	 iac_subscription  = null
    	 resource_group_location  = null
    	 resource_group_name  = null
    	 storage_account_name  = null
    	 storage_account_replication_type  = "LRS"
    	 storage_account_tier  = "Standard"
  }
  ```

## Resources

| Name | Type |
|------|------|
| [azuread_administrative_unit.global_subscription_rbac_administrative_unit](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/administrative_unit) | resource |
| [azuread_directory_role.privileged_role_admin](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/directory_role) | resource |
| [azuread_directory_role_assignment.initialize_platform_governance_managed_identity_global_admin](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/directory_role_assignment) | resource |
| [azuread_group.data_reader_data_access_rbac_group](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/resources/group) | resource |
| [azurerm_resource_group.initialize_platform_rg](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/resource_group) | resource |
| [azurerm_role_assignment.data_reader_data_access_rbac_group_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.initialize_platform_governance_managed_identity_tenant_root_owner](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/role_assignment) | resource |
| [azurerm_storage_account.initialize_platform_storage_account](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/storage_account) | resource |
| [azurerm_storage_container.sub_storage_container](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/storage_container) | resource |
| [azurerm_user_assigned_identity.initialize_platform_governance_managed_identity](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/user_assigned_identity) | resource |
| [time_sleep.wait_for_initialize_platform_governance_managed_identity](https://registry.terraform.io/providers/hashicorp/time/latest/docs/resources/sleep) | resource |
| [azurerm_management_group.tenant_root](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/management_group) | data source |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/subscription) | data source |

## Support
For further support please contact,
- Deepak Venugopal (deepak.venugopal@akersolutions.com)
- Shamsher Khan B (shamsher.khan.b@akersolutions.com)
- Vitthal Naikare (Vitthal.Naikare@akersolutions.com)
<!-- END_AUTOMATED_TF_DOCS_BLOCK -->