## Introduction

This module is used to move Subscriptions to a Management Group if specified

