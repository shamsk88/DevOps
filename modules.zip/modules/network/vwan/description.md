
## Introduction

This IAC module is used to create a peering between Azure Virtual Network (VNet) to a Virtual WAN hub allows the VNet to connect to other resources within the Virtual WANs in Azure. It performs the following tasks:

- Creates a peering between Azure Virtual Network (VNet) to a Virtual WAN hub
- By default, internet-bound traffic from the connected virtual network is routed through the Virtual WAN hub's firewall