## Subscription File Content
- Virtual Machines (Table)
- VNETs & Subnets (Table)
- Managed Identities (Table)
- Keyvaults (Table)