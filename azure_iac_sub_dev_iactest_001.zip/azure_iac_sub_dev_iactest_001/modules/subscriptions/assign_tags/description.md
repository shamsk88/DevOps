## Introduction

This module is used to assign Tags and their values to Subscriptions if specified 

