<!-- BEGIN_AUTOMATED_TF_DOCS_BLOCK -->

## Introduction

This IAC module is used to create a peering between Azure Virtual Network (VNet) to a Virtual WAN hub allows the VNet to connect to other resources within the Virtual WANs in Azure. It performs the following tasks:

- Creates a peering between Azure Virtual Network (VNet) to a Virtual WAN hub
- By default, internet-bound traffic from the connected virtual network is routed through the Virtual WAN hub's firewall
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.34.0 |
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_global_configuration"></a> [global\_configuration](#input\_global\_configuration) | (Required) The path to the global configuration YAML file | `string` | n/a | yes |
| <a name="input_network_dependency"></a> [network\_dependency](#input\_network\_dependency) | Dependency on network creation | `any` | n/a | yes |
| <a name="input_rg_dependency"></a> [rg\_dependency](#input\_rg\_dependency) | Dependency on resource group creation | `any` | n/a | yes |
| <a name="input_vwan"></a> [vwan](#input\_vwan) | (Required) The path to the yaml file containing ddos definitions. Refer sample in the templates folder. | `string` | n/a | yes |
  ## Usage
  Basic usage of this module is as follows:
  ```hcl
  module "example" {
    	 source  = "<module-path>"
    
	 # Required variables
    	 global_configuration  = 
    	 network_dependency  = 
    	 rg_dependency  = 
    	 vwan  = 
  }
  ```

## Resources

| Name | Type |
|------|------|
| [azurerm_virtual_hub_connection.vnet_connection](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/virtual_hub_connection) | resource |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/client_config) | data source |
| [azurerm_virtual_hub.virtual_hub](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/virtual_hub) | data source |
| [azurerm_virtual_network.vnet](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/virtual_network) | data source |

## Support
For further support please contact,
- Deepak Venugopal (deepak.venugopal@akersolutions.com)
- Shamsher Khan B (shamsher.khan.b@akersolutions.com)
- Vitthal Naikare (Vitthal.Naikare@akersolutions.com)
<!-- END_AUTOMATED_TF_DOCS_BLOCK -->