<!-- BEGIN_AUTOMATED_TF_DOCS_BLOCK -->

## Introduction

This module is used to create KeyVaults.It performs the following tasks,

- Create the key vault
- Configure key vault access configuration as a Azure role-based access control and grant      Permission to Azure AD Groups & Azure Ad Users to manage Keys,Secrets & Certificates via "Key Vault Administrator". if enable\_rbac\_authorization is set to true
- Configure key vault access configuration as a vault access policy and grant Permission to Azure AD Group & Azure Ad Users to manage Keys & Secrets & Certificates. if enable\_rbac\_authorization is set to false
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.34.0 |
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_global_configuration"></a> [global\_configuration](#input\_global\_configuration) | (Required) The path to the global configuration YAML file | `string` | n/a | yes |
| <a name="input_keyvault_definitions"></a> [keyvault\_definitions](#input\_keyvault\_definitions) | (Required) The path to the YAML file that contains the list of keyvaults to be procesed | `string` | n/a | yes |
  ## Usage
  Basic usage of this module is as follows:
  ```hcl
  module "example" {
    	 source  = "<module-path>"
    
	 # Required variables
    	 global_configuration  = 
    	 keyvault_definitions  = 
  }
  ```

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault.keyvaults](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/key_vault) | resource |
| [azurerm_role_assignment.keyvault_groups](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/role_assignment) | resource |
| [azurerm_role_assignment.keyvault_users](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/role_assignment) | resource |
| [azuread_group.groups](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/group) | data source |
| [azuread_user.users](https://registry.terraform.io/providers/hashicorp/azuread/latest/docs/data-sources/user) | data source |
| [azurerm_client_config.current](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/client_config) | data source |
| [azurerm_resource_group.keyvault_resource_group](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/resource_group) | data source |

## Support
For further support please contact,
- Deepak Venugopal (deepak.venugopal@akersolutions.com)
- Shamsher Khan B (shamsher.khan.b@akersolutions.com)
- Vitthal Naikare (Vitthal.Naikare@akersolutions.com)
<!-- END_AUTOMATED_TF_DOCS_BLOCK -->