## Introduction

This azure iac governance project details out the steps required to setup an Azure Landing Zone using Terraform. The project uses modules that are maintained in the "***azure_iac_modules***" repository. For access to the repository, please refer to the "***Contact***" section of this readme.

The following governance tasks are handled as part of the workflow,

- Setting up the foundation to use IAC in the environment. This is detailed in ***"1_initialize_platform.tf"***
- Creation of Management Groups as specified in the "***2_create_management_groups.tf**" file.
- Applying defined policies and their settings
- Onboarding of subscriptions with tasks mentioned in the ***subscription_onboarding*** module
  
## Prerequisites

The following are the prerequisites for setting up the platform governance workflow,

- An account with "***Privileged Role Administrator***" privileges on Entra ID
- Create a submodule for the "***azure_iac_modules***" repository in a folder called "***modules***" using the command,
  <pre>
    git submodule add <i>repository_url</i> modules
  </pre>
- Create a submodule for the "***azure_iac_global_configuration***" repository in a folder called "***global_configuration***" using the command,
  <pre>
    git submodule add <i>repository_url</i> global_configuration
  </pre>
  - verify that the "***global_configuration.json***" file in the folder "***global_configuration***" has valid parameters

## Platform Initialization

The azure platform needs to be initialized to support future deployments. This task is done using the initialize_platform module. If you already have an existing terraform infrastructure, this step can usually be ignored. The platform is to be initialized in the following way,

#### Step 1 : Authenticate to Azure
- Login to Azure with an account having "***Privileged Role Administrator***" permissions using the command,
  <pre>
   az login -t tenant_id
   ex: az login -t xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
  </pre>

#### Step 2: Create an Azure Subscription for Terraform
- Ensure that an Azure Subscription is created. This Azure Subscription will be used to host the Terraform State files, Managed Identities and other services that are needed to sustain the platform. It is recommended to create a separate Azure Subscription for this purpose.

#### Step 3: Initialize the platform
- Create a "***.tf***" file and ensure that only the "***initialize_platform***" module is called. All other "***.tf***" files must be commented out or blank. By default, this is specified in the "***1_initialize_platform.tf***" file.
- Ensure that there is no "backend" configuration specified in "***providers.tf***". This is required to generate a local "***.tfstate***" file. Initialize the platform and create a local terraform state file. By default this file is called "***terraform.tfstate***"

#### Step 4: Onboard the Azure Subscription for Terraform
- Onboard the Azure Subscription that is created to host the Terraform State files, Managed Identities and other services

#### Step 5: Migrate Terraform State Files
- Add the AzureRM Backend configuration and run a Terraform Init to migrate the locally created state file to the storage account
- Delete the files named "***terraform.tfstate***" and "***terraform.tfstate.backup***"
- The platform is now ready for subsequent configurations and deployments
