## Introduction

This document defines a consistent naming standard for Azure Management Groups, in alignment with the Microsoft Azure Cloud Adoption Framework. Adopting a standard improves resource discoverability, simplifies governance, and enables scalable growth across your Azure environment.

> ⚠️ Keep names concise and avoid special characters or spaces. Use PascalCase for clarity.

## Management Groups

Management Groups should be named using a structured and meaningful convention to reflect their purpose, scope, and organizational hierarchy. The naming convention for management groups is as follows,

        mg-<name identifier>

| Component     | Description                                                              | Example         |
|---------------|--------------------------------------------------------------------------|-----------------|
| `mg`       | Fixed prefix denoting a management group                               |        |
| `<name identifier>`     | Name of the management group. Can include functional or environmental contexts.   | `development`, `production`, `security`      |

Sample naming standards are shown below, 

| Management Group Name     | Purpose                                  | Level     | Notes                         |
|---------------------------|------------------------------------------|-----------|-------------------------------|
| `mg-production`| Contains production workloads that support real-time business functions    | Root+1    | Production Workloads   |
| `mg-development`| Contains development workloads that are used during for creation and testing purposes   | Root+1    | Development Workloads   |


## Subscriptions


## Resources