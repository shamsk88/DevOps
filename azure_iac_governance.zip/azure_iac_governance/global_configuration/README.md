### Introduction 

This repository contains information about the tenant and other global parameters for provisioning and managing Azure resources efficiently.

### Usage Directions

- Create a submodule for this repository in a folder called "***global_configuration***" using the command,
  <pre>
    git submodule add <i>repository_url</i> modules
  </pre>

## Support
For further support and on details on how to contribute, contact,
- Deepak Venugopal (Deepak.Venugopal@akersolutions.com)
- Shamsher Khan B (shamsher.khan.b@akersolutions.com)
- Vitthal Naikare (Vitthal.Naikare@akersolutions.com)