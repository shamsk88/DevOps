
## Introduction

This IAC module is used to create Virtual Networks and associated configurations in Azure. It performs the following tasks:

- Creates Virtual Networks
- Creates Subnets
- Create Network Security Group
- Associate Network Security Group to Subnet
- Adds a delete lock on the Virtual Network
- Attach ddos protection plan to Virtual Network