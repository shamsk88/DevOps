## Introduction

This module is used to create Linux based virtual machines. It performs the following tasks,

 - Create Linux virtual machines
 - Create the Managed Disk for each virtual machine
 - Attach managed disk to each virtual machine
 - Create the network interfaces for each virtual machine
 - Adds a delete lock on the virtual machine
 - Associates Virtual Machine to backup policy in Recovery Service Vault 



## Prerequisites
- The default login password for the Virtual machine should be provided through KeyVault.