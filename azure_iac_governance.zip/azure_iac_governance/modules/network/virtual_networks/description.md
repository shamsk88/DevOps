
## Introduction

This IAC module is used to create Virtual Networks and associated configurations in Azure. It performs the following tasks:

- Creates Virtual Networks
- Creates Subnets
- Create Network Security Group
- Associate Network Security Group to Subnet