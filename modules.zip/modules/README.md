
### Introduction 

This repository contains reusable IAC modules for provisioning and managing Azure resources efficiently.

### Prerequisites
Before using these modules, ensure you have:
- [OpenTofu](https://opentofu.org/) version 1.9 or above installed
- An active [Azure subscription](https://portal.azure.com/)
- [Azure CLI](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli) configured and authenticated

### Usage Directions

- Create a submodule for this repository in a folder called "***modules***" using the command,
  <pre>
    git submodule add <i>repository_url</i> modules
  </pre>

- The modules rely on a "***global_configuration.json***" file which contains information about the tenant and other global parameters. A sample for this file is available in the folder "***global_configuration***".

- To use a module, reference it in your IAC configuration:

  <pre>
    module "example" {
        source  = "module-path"
        global_configuration  = "global-configuration-path"
    }
  </pre>

### IAC Docs

- IAC Docs is used to create documentation for the modules. To install IAC Docs in your local environment, refer https://terraform-docs.io/user-guide/installation/
- A default configuration file optimized for the modules is available in "***modules/.terraform-docs.yml***"
- IAC Docs expects the modules to each have an introduction file called "***description.md***"
- To update the configuration, run the following command from the root directory,
  <pre>
    ./updatedocs.sh .
  </pre>

## Naming Conventions

This following prefixes are used accross all modules,

| Type 	| Prefix 	| Sample 	|
|---	|---	|---	|
| Administrative Unit 	| au 	| au-sub-prd-infr-01 	|
| Management Group 	| mg	| mg-applications 	|
| Security Group 	| sg	| sg-sub-prd-infr-01-contributor 	|
| Managed Identity 	| mid 	| mid-platform-governance 	|
| Storage Account 	| st 	| stdevinfrsi01 	|
| Resource Group 	| rg 	| rg-dev-infr-si-01 	|
| Key Vault 	| kv 	| kv-dev-infr-si-01 	|
| Application Security Group 	| asg 	| asg-dev-infr-si-01 	|
| Network Security Group 	| nsg 	| nsg-dev-infr-si-01 	|
| Virtual Networks 	| vnet 	| vnet-dev-infr-si-01 	|
| Recovery Service Vault 	| rsv 	| rsv-dev-infr-si-01 	|
| Recovery Service Vault Policy 	| pol 	| pol-dev-sql-saleforce-01 	|
| Virtual Machine 	| vm 	| vm-dev-infr-si-01 	|
| Data Disk 	| disk 	| disk-dev-infr-si-01 	|
| Network Interface 	| nic 	| nic-dev-infr-si-01 	|

## Support
For further support and on details on how to contribute, contact,
- Deepak Venugopal (Deepak.Venugopal@akersolutions.com)
- Shamsher Khan B (shamsher.khan.b@akersolutions.com)
- Vitthal Naikare (Vitthal.Naikare@akersolutions.com)