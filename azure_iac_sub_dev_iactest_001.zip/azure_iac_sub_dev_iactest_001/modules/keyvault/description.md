
## Introduction

This module is used to create KeyVaults.It performs the following tasks,

- Create the key vault
- Configure key vault access configuration as a Azure role-based access control and grant      Permission to Azure AD Groups & Azure Ad Users to manage Keys,Secrets & Certificates via "Key Vault Administrator". if enable_rbac_authorization is set to true
- Configure key vault access configuration as a vault access policy and grant Permission to Azure AD Group & Azure Ad Users to manage Keys & Secrets & Certificates. if enable_rbac_authorization is set to false