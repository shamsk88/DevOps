<!-- BEGIN_AUTOMATED_TF_DOCS_BLOCK -->
## Introduction

This module is used to create resource groups. This module performs the following tasks,

- ### Create Resource Groups (create\\_resource\\_group.tf)
  - Create resource groups. The resource groups are created in the current subscription.

- ### Configure RBAC Roles & Security Groups (configure\\_rbac\\_groups.tf)
  - Create RBAC groups in Entra for the each resource group and place it in the appropriate Administrative Unit
  - Map the RBAC groups to the appropriate roles for each resource group
  - Add members to the resource group specific RBAC groups if specified
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azuread"></a> [azuread](#requirement\_azuread) | 3.3.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.34.0 |
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_definitions"></a> [definitions](#input\_definitions) | (Required) The path to the yaml file containing resource group definitions. Refer sample in the templates folder. | `string` | n/a | yes |
| <a name="input_global_configuration"></a> [global\_configuration](#input\_global\_configuration) | (Required) The path to the global configuration YAML file | `string` | n/a | yes |
| <a name="input_security_group_prefix"></a> [security\_group\_prefix](#input\_security\_group\_prefix) | The prefix used while creating the security groups in Entra. Defaults to 'sg'. | `string` | `"sg"` | no |
  ## Usage
  Basic usage of this module is as follows:
  ```hcl
  module "example" {
    	 source  = "<module-path>"
    
	 # Required variables
    	 definitions  = 
    	 global_configuration  = 
    
	 # Optional variables
    	 security_group_prefix  = "sg"
  }
  ```

## Resources

| Name | Type |
|------|------|
| [azuread_group.rg_rbac_group](https://registry.terraform.io/providers/hashicorp/azuread/3.3.0/docs/resources/group) | resource |
| [azuread_group_member.rg_rbac_group_add_default_members](https://registry.terraform.io/providers/hashicorp/azuread/3.3.0/docs/resources/group_member) | resource |
| [azurerm_resource_group.rg](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/resource_group) | resource |
| [azurerm_role_assignment.rg_specific_role_assignment](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/role_assignment) | resource |
| [azuread_administrative_unit.current](https://registry.terraform.io/providers/hashicorp/azuread/3.3.0/docs/data-sources/administrative_unit) | data source |
| [azuread_group.this](https://registry.terraform.io/providers/hashicorp/azuread/3.3.0/docs/data-sources/group) | data source |
| [azurerm_subscription.current](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/subscription) | data source |

## Support
For further support please contact,
- Deepak Venugopal (deepak.venugopal@akersolutions.com)
- Shamsher Khan B (shamsher.khan.b@akersolutions.com)
- Vitthal Naikare (Vitthal.Naikare@akersolutions.com)
<!-- END_AUTOMATED_TF_DOCS_BLOCK -->