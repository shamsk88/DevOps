## Introduction

This module is used to create default storage containers for storing state files for each Subscription

