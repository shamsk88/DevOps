<!-- BEGIN_AUTOMATED_TF_DOCS_BLOCK -->
## Introduction

This module is used to create Windows based virtual machines. It performs the following tasks,

 - Creates Windows virtual machines
 - Create the Managed Disk for each virtual machine
 - Attach managed disk to each virtual machine
 - Create the network interfaces for each virtual machine
 - Adds a delete lock on the virtual machine
 - Associates Virtual Machine to backup policy in Recovery Service Vault

## Prerequisites
- The default login password for the Virtual Machine should be provided through KeyVault.
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.34.0 |
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_global_configuration"></a> [global\_configuration](#input\_global\_configuration) | (Required) The path to the global configuration YAML file | `string` | n/a | yes |
| <a name="input_virtual_machine_definitions"></a> [virtual\_machine\_definitions](#input\_virtual\_machine\_definitions) | (Required) The path to the yaml file containing virtual machine definitions. Refer sample in the templates folder. | `string` | n/a | yes |
  ## Usage
  Basic usage of this module is as follows:
  ```hcl
  module "example" {
    	 source  = "<module-path>"
    
	 # Required variables
    	 global_configuration  = 
    	 virtual_machine_definitions  = 
  }
  ```

## Resources

| Name | Type |
|------|------|
| [azurerm_backup_protected_vm.vm_backups](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/backup_protected_vm) | resource |
| [azurerm_managed_disk.managed_disks](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/managed_disk) | resource |
| [azurerm_management_lock.vm_delete_lock](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/management_lock) | resource |
| [azurerm_network_interface.virtualmachine_network_interfaces](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/network_interface) | resource |
| [azurerm_virtual_machine_data_disk_attachment.attach_windows_disks](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/virtual_machine_data_disk_attachment) | resource |
| [azurerm_windows_virtual_machine.vms](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/windows_virtual_machine) | resource |
| [azurerm_client_config.config](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/client_config) | data source |
| [azurerm_key_vault.key_vaults](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/key_vault) | data source |
| [azurerm_key_vault_secret.key_vault_secrets](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/key_vault_secret) | data source |
| [azurerm_resource_group.vm_resource_group](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/resource_group) | data source |
| [azurerm_subnet.subnets](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/data-sources/subnet) | data source |

## Support
For further support please contact,
- Deepak Venugopal (deepak.venugopal@akersolutions.com)
- Shamsher Khan B (shamsher.khan.b@akersolutions.com)
- Vitthal Naikare (Vitthal.Naikare@akersolutions.com)
<!-- END_AUTOMATED_TF_DOCS_BLOCK -->