## Introduction

This module is used to onboard a new Azure Subscription to the Azure Landing Zone. This module performs the following tasks,

- ### Configure Administrative Units (configure\_administrative\_units.tf)
  - Create an Administrative Unit for each subscription. This will contain RBAC groups for the resources created inside this Subscription.

- ### Configure RBAC Roles & Security Groups (configure\_rbac\_groups.tf)
  - Create RBAC groups in Entra for each subscription and place it in the appropriate Administrative Unit
  - Map the RBAC groups to the appropriate roles for each subscription
  - Add members to the subscription specific RBAC groups

- ### Configure Managed Identities (configure\_managed\_identities.tf)
  - Create a managed identity for each subscription
  - Map the managed identity into the owner role of the respective subscription. This access is required to manage permissions and roles of underlying resources.
  - Create security group to host all Managed Identities
  - Add all managed identities to the security group created above
  - Map the security group containing all the managed identities to the "**Network Contributor**" role of all subscriptions. This access is required to create VNET peerings.
  - Provide Directory Reader role on the Tenant to all the managed identities
  - Provide Group Administrator role on the Tenant to all the managed identities. This resource assignment is used if the Entra Tenant is NOT licensed with a P1 or P2 license. The scope for this assignment is valid if "***entra\_license\_available***" is set to "***true***".
  - Provide Group Administrator role on the subscription specific AU to the subscription specific managed identity. This resource assignment is used if the Entra Tenant is licensed with a P1 or P2 license. The scope for this assignment is valid if "***entra\_license\_available***" is set to "***true***".
  - Map the managed identity into the Storage Blob Data Contributor role of the respective storage container
  - Map the managed identity into the Storage Account Key Operator Service role of the respective storage container
  - Add the managed identity of each subscription into the Reader and Data Access security group created above

