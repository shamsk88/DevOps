<!-- BEGIN_AUTOMATED_TF_DOCS_BLOCK -->
## Introduction

This module is used to create default storage containers for storing state files for each Subscription
## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | 4.34.0 |
## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_global_configuration"></a> [global\_configuration](#input\_global\_configuration) | (Required) The path to the global configuration yaml file | `string` | n/a | yes |
| <a name="input_subscriptions"></a> [subscriptions](#input\_subscriptions) | (Required) The path to the yaml file containing subscription specific information. Refer sample in the templates folder. | `string` | n/a | yes |
  ## Usage
  Basic usage of this module is as follows:
  ```hcl
  module "example" {
    	 source  = "<module-path>"
    
	 # Required variables
    	 global_configuration  = 
    	 subscriptions  = 
  }
  ```

## Resources

| Name | Type |
|------|------|
| [azurerm_storage_container.sub_storage_container](https://registry.terraform.io/providers/hashicorp/azurerm/4.34.0/docs/resources/storage_container) | resource |

## Support
For further support please contact,
- Deepak Venugopal (deepak.venugopal@akersolutions.com)
- Shamsher Khan B (shamsher.khan.b@akersolutions.com)
- Vitthal Naikare (Vitthal.Naikare@akersolutions.com)
<!-- END_AUTOMATED_TF_DOCS_BLOCK -->